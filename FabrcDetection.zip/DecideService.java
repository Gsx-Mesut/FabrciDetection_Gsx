package com.yuansheng.fabricdetect.java.decide;

import android.content.Context;
import android.util.Log;

import com.iflytek.south.industry.android.core.enums.DefectType;
import com.iflytek.south.industry.android.model.bo.CycleFramePredictData;
import com.iflytek.south.industry.android.model.engine.DecideResult;
import com.iflytek.south.industry.android.model.engine.DetectResult;
import com.iflytek.south.industry.android.model.engine.InnerDetectionService;
import com.yuansheng.fabricdetect.java.detection.CycleCompletedEvent;
import com.yuansheng.fabricdetect.java.detection.EngineManager;
import com.yuansheng.fabricdetect.java.event.command.StartDetectionCommand;
import com.yuansheng.fabricdetect.java.event.command.StopDetectionCommand;
import com.yuansheng.fabricdetect.java.event.command.UpdateParamsCommand;
import com.yuansheng.fabricdetect.java.event.hardware.HardwareStateEvent;
import com.yuansheng.fabricdetect.java.params.ParamsManager;
import com.yuansheng.fabricdetect.java.utils.EventBusUtils;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 决策服务，负责对检测结果进行决策
 * 主要作用是封装InnerDetectionService的doDecide逻辑，并发布决策结果事件
 */
public class DecideService {
    private static final String TAG = "DecideService";
    
    private final Context context;
    private final ParamsManager paramsManager;
    private EngineManager engineManager;
    
    // 决策线程池
    private ExecutorService executor;
    
    // 决策状态
    private final AtomicBoolean isRunning = new AtomicBoolean(false);
    private final AtomicBoolean isPaused = new AtomicBoolean(false);
    
    // 是否自动决策
    private boolean autoDecide = true;
    
    /**
     * 构造函数
     */
    public DecideService(Context context) {
        this.context = context.getApplicationContext();
        this.paramsManager = ParamsManager.getInstance(context);
        
        // 初始化线程池
        executor = Executors.newSingleThreadExecutor();
        
        // 注册EventBus
        EventBusUtils.register(this);
    }
    
    /**
     * 初始化决策服务
     */
    public boolean initialize() {
        Log.d(TAG, "初始化决策服务");
        
        try {
            // 获取引擎管理器
            engineManager = EngineManager.getInstance(context);
            
            // 检查是否有可用的InnerDetectionService
            if (engineManager.getInnerDetectionService() == null) {
                Log.w(TAG, "InnerDetectionService不可用，部分决策功能将不可用");
                // 这里不返回false，因为我们希望即使没有InnerDetectionService也能继续运行
            }
            
            Log.d(TAG, "决策服务初始化成功");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "初始化决策服务失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 启动决策服务
     */
    public void start() {
        if (!isRunning.get()) {
            Log.d(TAG, "启动决策服务");
            isRunning.set(true);
            isPaused.set(false);
        } else {
            Log.w(TAG, "决策服务已在运行中");
        }
    }
    
    /**
     * 暂停决策服务
     */
    public void pause() {
        if (isRunning.get() && !isPaused.get()) {
            Log.d(TAG, "暂停决策服务");
            isPaused.set(true);
        }
    }
    
    /**
     * 恢复决策服务
     */
    public void resume() {
        if (isRunning.get() && isPaused.get()) {
            Log.d(TAG, "恢复决策服务");
            isPaused.set(false);
        }
    }
    
    /**
     * 停止决策服务
     */
    public void stop() {
        if (isRunning.get()) {
            Log.d(TAG, "停止决策服务");
            isRunning.set(false);
            isPaused.set(false);
        } else {
            Log.w(TAG, "决策服务未在运行");
        }
    }
    
    /**
     * 设置是否自动决策
     */
    public void setAutoDecide(boolean autoDecide) {
        this.autoDecide = autoDecide;
        Log.d(TAG, "设置自动决策: " + autoDecide);
    }
    
    /**
     * 接收开始检测命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onStartDetectionCommand(StartDetectionCommand command) {
        Log.d(TAG, "接收到开始检测命令，自动决策: " + command.isAutoDecide());
        setAutoDecide(command.isAutoDecide());
        start();
    }
    
    /**
     * 接收停止检测命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onStopDetectionCommand(StopDetectionCommand command) {
        Log.d(TAG, "接收到停止检测命令: " + command.getReason());
        stop();
    }
    
    /**
     * 接收参数更新命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onUpdateParamsCommand(UpdateParamsCommand command) {
        if (command != null && command.getParams() != null) {
            Log.d(TAG, "接收到参数更新命令: " + command.getParams().toString());
            // 决策服务不需要直接处理DCD引擎参数，InnerDetectionService会自行处理
        }
    }
    
    /**
     * 接收硬件状态事件
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onHardwareStateEvent(HardwareStateEvent event) {
        switch (event.getState()) {
            case ERROR:
                // 硬件错误，暂停决策
                Log.d(TAG, "接收到硬件错误状态，暂停决策: " + event.getMessage());
                pause();
                break;
            case STOPPED:
                // 硬件停止，停止决策
                Log.d(TAG, "接收到硬件停止状态，停止决策");
                stop();
                break;
        }
    }
    
    /**
     * 接收检测周期完成事件
     * 当一圈检测完成时，执行决策并发布决策结果事件
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onCycleCompletedEvent(CycleCompletedEvent event) {
        if (isRunning.get() && !isPaused.get() && autoDecide) {
            Log.d(TAG, "接收到一圈检测完成事件，开始决策");
            
            executor.execute(() -> {
                try {
                    List<DetectResult> detectResults = event.getDetectResults();
                    long cycleCount = event.getPulseCount();
                    
                    // 执行决策
                    DecideResult decideResult = doDecide(detectResults);
                    
                    if (decideResult != null) {
                        Log.d(TAG, "决策完成，发布决策结果事件");
                        
                        // 记录决策结果
                        logDecisionResult(decideResult);
                        
                        // 发布决策结果事件
                        EventBusUtils.post(new DecisionResultEvent(decideResult, detectResults, cycleCount));
                    } else {
                        Log.w(TAG, "决策结果为空");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "决策过程中发生异常: " + e.getMessage(), e);
                }
            });
        }
    }
    
    /**
     * 执行决策
     * 这是核心方法，封装了InnerDetectionService中的doDecide逻辑
     */
    public DecideResult doDecide(List<DetectResult> detectResults) {
        if (detectResults == null || detectResults.isEmpty()) {
            Log.w(TAG, "检测结果为空，无法进行决策");
            return null;
        }
        
        try {
            // 获取InnerDetectionService
            InnerDetectionService innerDetectionService = engineManager.getInnerDetectionService();
            if (innerDetectionService == null) {
                Log.e(TAG, "InnerDetectionService不可用，无法进行决策");
                return null;
            }
            
            // 创建周期帧预测数据
            CycleFramePredictData cycleData = new CycleFramePredictData();
            cycleData.setDataList(detectResults);
            
            // 直接调用InnerDetectionService的doDecide方法执行决策
            // InnerDetectionService内部已经处理了各项参数
            return innerDetectionService.doDecide(cycleData);
        } catch (Exception e) {
            Log.e(TAG, "执行决策失败: " + e.getMessage(), e);
            return null;
        }
    }
    
    /**
     * 记录决策结果详情到日志
     */
    private void logDecisionResult(DecideResult decideResult) {
        StringBuilder sb = new StringBuilder("决策结果: ");

        // 添加缺陷类型信息
        DefectType defectType = decideResult.getDefType();
        if (defectType != null) {
            sb.append("缺陷类型: ").append(defectType.name())
              .append("(").append(defectType.getCode()).append("), ");
        }

        // 添加多圈决策结果
        DefectType multiDefType = decideResult.getMultiDefType();
        if (multiDefType != null) {
            sb.append("多圈决策结果: ").append(multiDefType.name())
              .append("(").append(multiDefType.getCode()).append("), ");
        }

        // 添加缺陷检测结果
        sb.append("断针: ").append(decideResult.isDuanzhen())
            .append(", 数量: ").append(decideResult.getDuanzhenNum()).append("; ");

        sb.append("飞根: ").append(decideResult.isFeigen())
            .append(", 数量: ").append(decideResult.getFeigenNum()).append("; ");

        sb.append("破洞: ").append(decideResult.isPodong())
            .append(", 数量: ").append(decideResult.getPodongNum()).append("; ");

        sb.append("小缺陷: ").append(decideResult.isTiny())
            .append(", 数量: ").append(decideResult.getTinyNum());

        Log.d(TAG, sb.toString());
    }
    
    /**
     * 释放资源
     */
    public void release() {
        Log.d(TAG, "释放决策服务资源");
        
        // 停止决策
        stop();
        
        // 关闭线程池
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
            executor = null;
        }
        
        // 取消EventBus注册
        EventBusUtils.unregister(this);
        
        // 不需要释放引擎管理器，由ServiceManager管理
        this.engineManager = null;
    }
}