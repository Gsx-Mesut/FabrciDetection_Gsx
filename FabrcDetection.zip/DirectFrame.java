/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.util.Log
 */
package com.iflytek.south.industry.android.camera.core;

import android.graphics.Bitmap;
import android.util.Log;
import com.iflytek.south.industry.android.context.engine.Image;

public class DirectFrame
        implements Image {
    public static final int ALPHA = 1;
    public static final int RAW16 = 2;
    public static final int RGB = 3;
    public volatile long addr;
    public final int channel;
    public final int height;
    public volatile boolean released = false;
    public final int size;
    public final int width;

    public DirectFrame(long l2, int n2, int n3, int n4, int n5) {
        this.addr = l2;
        this.size = n2;
        this.width = n3;
        this.height = n4;
        this.channel = n5;
    }

    @Override
    public int channel() {
        return this.channel;
    }

    @Override
    public byte[] data() {
        return this.getData0(this.addr, this.size);
    }

    @Override
    public void finalize() throws Throwable {
        this.release();
        super.finalize();
    }

    @Override
    public String format() {
        return "jpeg";
    }

    public long getAddr() {
        return this.addr;
    }

    @Override
    public boolean getData(byte[] byArray) {
        return false;
    }

    public native byte[] getData0(long var1, int var3);

    public int getSize() {
        return this.size;
    }

    @Override
    public int height() {
        return this.height;
    }

    @Override
    public void release() {
        if (!this.released && this.addr != 0L && this.addr != -1L) {
            this.released = true;
            this.release0(this.addr, this.size);
            this.addr = 0L;
        }
    }

    public native void release0(long var1, int var3);

    @Override
    public int size() {
        return this.size;
    }

    public Bitmap toBitmap(boolean bl, int n2, int n3, Bitmap.Config config) {
        if (this.released) {
            Log.e((String)"DirectFrame", (String)"图片已经释放，无法转换成bitmap");
            return null;
        }
        Log.d("DirectFrame", "toBitmap: " + this.addr + ", " + this.width + ", " + this.height + ", " + this.channel + ", " + bl + ", " + n2 + ", " + n3 + ", " + config);
        return this.toBitmap0(this.addr, this.width, this.height, this.channel, bl, n2, n3, config);
    }

    public native Bitmap toBitmap0(long var1, int var3, int var4, int var5, boolean var6, int var7, int var8, Bitmap.Config var9);

    @Override
    public int width() {
        return this.width;
    }

    public int writeToFile(String string2) {
        return this.writeToFile0(this.addr, string2, this.width, this.height, this.channel, 90);
    }

    public int writeToFile(String string2, int n2) {
        return this.writeToFile0(this.addr, string2, this.width, this.height, this.channel, n2);
    }

    public native int writeToFile0(long var1, String var3, int var4, int var5, int var6, int var7);
}

