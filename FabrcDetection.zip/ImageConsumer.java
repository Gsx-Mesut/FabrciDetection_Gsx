package com.yuansheng.fabricdetect.java.utils;

import android.util.Log;

import com.iflytek.south.industry.android.camera.core.DirectFrame;
import com.iflytek.south.industry.android.context.engine.Image;
import com.yuansheng.fabricdetect.java.camera.ImageManager;
import com.yuansheng.fabricdetect.java.camera.ImageManager.ImageWrapper;
import com.yuansheng.fabricdetect.java.detection.DetectService;

public class ImageConsumer implements ImageProcessor {
    private static final String TAG = "ImageConsumer";
    private final ImageQueueManager imageQueueManager;
    private final DetectService detectService;
    private volatile boolean isRunning = false;
    private Thread consumerThread;

    public ImageConsumer(ImageQueueManager imageQueueManager, DetectService detectService) {
        this.imageQueueManager = imageQueueManager;
        this.detectService = detectService;
    }

    public void start() {
        if (!isRunning) {
            isRunning = true;
            consumerThread = new Thread(() -> {
                while (isRunning && !Thread.currentThread().isInterrupted()) {
                    try {
                        ImageWrapper wrapper = imageQueueManager.pollImage();
                        if (wrapper != null) {
                            run(wrapper);
                        } else {
                            Thread.sleep(10); // 避免空转
                        }
                    } catch (InterruptedException e) {
                        Log.d(TAG, "图像消费者被中断");
                        Thread.currentThread().interrupt();
                        break;
                    } catch (Exception e) {
                        Log.e(TAG, "处理图像时发生错误", e);
                    }
                }
            });
            consumerThread.start();
            Log.d(TAG, "图像消费者已启动");
        }
    }

    public void stop() {
        isRunning = false;
        if (consumerThread != null) {
            consumerThread.interrupt();
            consumerThread = null;
        }
        Log.d(TAG, "图像消费者已停止");
    }

    @Override
    public void run(ImageWrapper wrapper) {
        if (wrapper != null) {
            try {
                DirectFrame image = (DirectFrame)wrapper.getImage();
                if (image != null && detectService != null) {
                    detectService.processFrame(image);
                }
            } finally {
                wrapper.release();
            }
        }
    }
} 