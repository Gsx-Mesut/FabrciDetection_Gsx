package com.yuansheng.fabricdetect.java.handler;


import android.graphics.*;
import android.util.Log;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class CalibrationHandler {
    private Paint paint;
    private int textSize = 60; // 将字体大小从80改为60
    private int[] valid_gray_range = new int[]{80, 110};
    private PathEffect dashEffect; // 虚线效果

    public CalibrationHandler() {
        // 修改虚线效果，使用较小的虚线间隔
        this.dashEffect = new DashPathEffect(new float[]{8.0f, 8.0f}, 1.0f);
    }

    // 绘制校准线
    public void drawCalibrationLine(Paint paint, Bitmap bitmap, Canvas canvas) {
        int width = canvas.getWidth();
        int height = canvas.getHeight();

        // 重置画笔状态
        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);

        // 1. 绘制中心黄色虚线
        paint.setPathEffect(this.dashEffect); // 使用虚线效果
        paint.setColor(Color.YELLOW);
        paint.setStrokeWidth(2);
        float centerX = width / 2;
        canvas.drawLine(centerX, 0, centerX, height, paint);

        // 2. 绘制三个检测区域的虚线矩形
        paint.setPathEffect(this.dashEffect);
        paint.setColor(Color.RED);
        paint.setStrokeWidth(2);

        int marginX = width / 10;
        int marginY = height / 8;
        int bottomMargin = height / 3;
        float top = marginY;
        float bottom = height - marginY - bottomMargin;

        // 计算三个区域的位置
        int areaWidth = (width - marginX * 2) / 3;
        for (int i = 0; i < 3; i++) {
            float left = marginX + i * areaWidth;
            float right = left + areaWidth;
            canvas.drawRect(left, top, right, bottom, paint);
        }

        // 3. 绘制灰度值
        paint.setPathEffect(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(textSize); // 使用较小的字体大小

        // 计算并显示各区域灰度值
        double gray1 = countGrayAvg(bitmap, 0);
        double gray2 = countGrayAvg(bitmap, 1);
        double gray3 = countGrayAvg(bitmap, 2);

        // 调整文字位置
        float textY = bottom + textSize + 10;
        drawGrayValue(canvas, paint, gray1, marginX + areaWidth/2, textY);
        drawGrayValue(canvas, paint, gray2, marginX + areaWidth*1.5f, textY);
        drawGrayValue(canvas, paint, gray3, marginX + areaWidth*2.5f, textY);
    }

    private void drawGrayValue(Canvas canvas, Paint paint, double value, float x, float y) {
        boolean isValid = value >= valid_gray_range[0] && value <= valid_gray_range[1];
        paint.setColor(isValid ? Color.GREEN : Color.RED);
        String text = String.format("%.1f", value);
        float textWidth = paint.measureText(text);
        // 居中显示文字
        canvas.drawText(text, x - textWidth/2, y, paint);
    }

    // 移除 drawChangeFabricLine 方法，因为不再需要
    
    // 计算区域灰度平均值
    public double countGrayAvg(Bitmap bitmap, int section) {
        if (bitmap == null) {
            Log.e("Calibration", "bitmap为空");
            return 0.0;
        }

        try {
            int marginX = bitmap.getWidth() / 10;
            int marginY = bitmap.getHeight() / 8;
            int width = bitmap.getWidth() - marginX * 2;
            int height = bitmap.getHeight() - marginY * 2 - bitmap.getHeight() / 3;
            int sectionWidth = width / 3;

            Log.d("Calibration", String.format("计算第%d区域灰度值, 区域大小: %dx%d",
                    section, sectionWidth, height));

            int[] pixels = new int[sectionWidth * height];
            bitmap.getPixels(pixels, 0, sectionWidth,
                    section * sectionWidth + marginX, marginY,
                    sectionWidth, height);

            long sum = 0;
            for (int pixel : pixels) {
                sum += pixel & 0xFF;
            }

            double avgGray = (double) sum / pixels.length;
            Log.d("Calibration", String.format("区域 %d 计算完成，平均灰度值: %.1f", section, avgGray));
            return avgGray;

        } catch (Exception e) {
            Log.e("Calibration", "计算灰度值失败: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
}