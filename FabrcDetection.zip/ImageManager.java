package com.yuansheng.fabricdetect.java.camera;

import android.util.Log;
import com.iflytek.south.industry.android.context.engine.Image;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ImageManager {
    private static final String TAG = "ImageManager";
    private static final int MAX_ACTIVE_IMAGES = 10;
    
    private final ConcurrentHashMap<Long, ImageWrapper> imagePool = new ConcurrentHashMap<>();
    private final AtomicInteger activeImageCount = new AtomicInteger(0);
    // 使用Map管理不同Activity的监听器
    private final Map<String, ImageListener> activityListeners = new ConcurrentHashMap<>();

    public interface ImageListener {
        void onImageAvailable(ImageWrapper imageWrapper);
    }

    public void setImageListener(String activityTag, ImageListener listener) {
        if (listener != null) {
            activityListeners.put(activityTag, listener);
        } else {
            activityListeners.remove(activityTag);
        }
        Log.d(TAG, "设置" + activityTag + "的图像监听器，当前活跃监听器: " + activityListeners.keySet());
    }

    public void removeImageListener(String activityTag) {
        activityListeners.remove(activityTag);
        Log.d(TAG, "移除" + activityTag + "的图像监听器，当前活跃监听器: " + activityListeners.keySet());
    }

    // 添加移除所有监听器的方法
    public void removeAllImageListeners() {
        activityListeners.clear();
        Log.d(TAG, "清空所有图像监听器");
    }

    public ImageWrapper acquireImage(Image image) {
        if (image == null) {
            return null;
        }

        if (activeImageCount.get() >= MAX_ACTIVE_IMAGES) {
            cleanupOldImages();
        }

        ImageWrapper wrapper = new ImageWrapper(image);
        imagePool.put(wrapper.timestamp, wrapper);
        activeImageCount.incrementAndGet();
        return wrapper;
    }

    private void cleanupOldImages() {
        long currentTime = System.currentTimeMillis();
        imagePool.forEach((timestamp, wrapper) -> {
            if (currentTime - timestamp > 3500) {
                if (wrapper.release()) {
                    imagePool.remove(timestamp);
                    activeImageCount.decrementAndGet();
                }
            }
        });
    }

    public void handleImage(Image image) {
        if (image == null) {
            Log.e(TAG, "收到空图像");
            return;
        }
        
        ImageWrapper wrapper = acquireImage(image);
        if (wrapper == null) {
            Log.e(TAG, "创建图像包装器失败");
            return;
        }

        // 通知所有活跃的监听器
        for (Map.Entry<String, ImageListener> entry : activityListeners.entrySet()) {
            try {
                entry.getValue().onImageAvailable(wrapper);
            } catch (Exception e) {
                Log.e(TAG, entry.getKey() + "监听器处理异常", e);
                wrapper.release();
            }
        }
    }

    public void release() {
        imagePool.forEach((timestamp, wrapper) -> wrapper.release());
        imagePool.clear();
        activeImageCount.set(0);
        activityListeners.clear();
    }

    public static class ImageWrapper {
        private final Image image;
        private final long timestamp;
        private final AtomicInteger referenceCount;
        private volatile boolean isReleased;

        public ImageWrapper(Image image) {
            this.image = image;
            this.timestamp = System.currentTimeMillis();
            this.referenceCount = new AtomicInteger(1);
            this.isReleased = false;
        }

        public Image getImage() {
            if (isReleased) {
                Log.e(TAG, "尝试获取已释放的图像");
                return null;
            }
            referenceCount.incrementAndGet();
            return image;
        }

        public boolean release() {
            if (isReleased) {
                return false;
            }
            if (referenceCount.decrementAndGet() <= 0) {
                isReleased = true;
                try {
                    image.release();
                    return true;
                } catch (Exception e) {
                    Log.e(TAG, "释放图像资源失败", e);
                    return false;
                }
            }
            return false;
        }

        public boolean isReleased() {
            return isReleased;
        }
    }
}