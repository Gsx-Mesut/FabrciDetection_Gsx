package com.yuansheng.fabricdetect.java.detection;

import com.iflytek.south.industry.android.camera.core.DirectFrame;
import com.iflytek.south.industry.android.model.engine.DetectResult;

/**
 * 检测包装类，用于将检测结果与原始帧关联起来
 */
public class DetectionWrapper {
    private final DetectResult detectResult;
    private final DirectFrame originalFrame;
    
    /**
     * 构造函数
     * @param detectResult 检测结果
     * @param originalFrame 原始帧
     */
    public DetectionWrapper(DetectResult detectResult, DirectFrame originalFrame) {
        this.detectResult = detectResult;
        this.originalFrame = originalFrame;
    }
    
    /**
     * 获取检测结果
     * @return 检测结果对象
     */
    public DetectResult getDetectResult() {
        return detectResult;
    }
    
    /**
     * 获取原始帧
     * @return 原始帧对象
     */
    public DirectFrame getOriginalFrame() {
        return originalFrame;
    }
}