package com.yuansheng.fabricdetect.java.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.provider.MediaStore;
import android.util.Log;
import android.content.Intent;

import com.iflytek.south.industry.android.model.engine.DecideResult;
import com.iflytek.south.industry.android.model.engine.DetectResult;
import com.iflytek.south.industry.android.model.engine.Detect;
import com.iflytek.south.industry.android.core.enums.DefectType;
import com.yuansheng.fabricdetect.java.DefectStopActivity;
import com.yuansheng.fabricdetect.java.decide.DecisionResultEvent;
import com.yuansheng.fabricdetect.java.detection.DetectionWrapper;
import com.yuansheng.fabricdetect.java.event.command.StopDetectionCommand;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;
import java.util.ArrayList;

public class DefectImageSaver {
    private static final String TAG = "DefectImageSaver";
    private final Context context;
    private List<DetectionWrapper> currentCycleResults;

    public DefectImageSaver(Context context) {
        this.context = context;
        EventBusUtils.register(this);
    }

    public void setCurrentCycleResults(List<DetectionWrapper> results) {
        Log.d(TAG, "接收到当前圈的检测结果，数量: " + (results != null ? results.size() : 0));
        this.currentCycleResults = new ArrayList<>(results);
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onDecisionResult(DecisionResultEvent event) {
        Log.d(TAG, "收到决策结果事件");

        if (event == null) {
            Log.e(TAG, "决策事件为空");
            return;
        }
        DecideResult decideResult = event.getDecideResult();
        if (decideResult == null) {
            Log.e(TAG, "决策结果为空");
            return;
        }

        // 获取多圈决策结果类型
        DefectType multiDefType = decideResult.getMultiDefType();
        if (multiDefType == null || multiDefType == DefectType.NORMAL) {
            Log.d(TAG, "多圈决策结果为正常，不保存图片");
            return;
        }

        // 打印完整的决策结果信息
        Log.d(TAG, String.format("多圈决策类型: %s, 决策详情 - 断针:%b(%d), 飞根:%b(%d), 破洞:%b(%d), 小缺陷:%b(%d)",
                multiDefType.getName(),
                decideResult.isDuanzhen(), decideResult.getDuanzhenNum(),
                decideResult.isFeigen(), decideResult.getFeigenNum(),
                decideResult.isPodong(), decideResult.getPodongNum(),
                decideResult.isTiny(), decideResult.getTinyNum()));

        // 根据缺陷类型获取对应的关键帧列表
        List<Integer> keyFrames = new ArrayList<>();
        if (decideResult.isDuanzhen()) {
            keyFrames.addAll(decideResult.getDuanzhenKeyFrames());
            Log.d(TAG, "添加断针关键帧: " + decideResult.getDuanzhenKeyFrames().size());
        }
        if (decideResult.isFeigen()) {
            keyFrames.addAll(decideResult.getFeigenKeyFrames());
            Log.d(TAG, "添加飞根关键帧: " + decideResult.getFeigenKeyFrames().size());
        }
        if (decideResult.isPodong()) {
            keyFrames.addAll(decideResult.getPodongKeyFrames());
            Log.d(TAG, "添加破洞关键帧: " + decideResult.getPodongKeyFrames().size());
        }
        if (decideResult.isTiny()) {
            keyFrames.addAll(decideResult.getTinyKeyFrames());
            Log.d(TAG, "添加小缺陷关键帧: " + decideResult.getTinyKeyFrames().size());
        }

        if (keyFrames.isEmpty()) {
            Log.w(TAG, "未找到任何关键帧");
            return;
        }

        Log.d(TAG, "获取到关键帧数量: " + keyFrames.size());

        if (currentCycleResults == null || currentCycleResults.isEmpty()) {
            Log.e(TAG, "当前圈结果为空");
            return;
        }

        // 找出关键帧中置信度最高的检测结果
        float highestConfidence = 0;
        DetectionWrapper bestWrapper = null;
        DetectResult bestResult = null;

        for (Integer frameIndex : keyFrames) {
            Log.d(TAG, "处理关键帧 index: " + frameIndex +
                    ", currentCycleResults size: " + currentCycleResults.size());

            if (frameIndex >= 0 && frameIndex < currentCycleResults.size()) {
                DetectionWrapper wrapper = currentCycleResults.get(frameIndex);
                DetectResult detectResult = wrapper.getDetectResult();

                if (detectResult != null && detectResult.getDetects() != null) {
                    for (Detect detect : detectResult.getDetects()) {
                        if (detect.getScore() > highestConfidence) {
                            highestConfidence = detect.getScore();
                            bestWrapper = wrapper;
                            bestResult = detectResult;
                            Log.d(TAG, "找到更高置信度: " + highestConfidence);
                        }
                    }
                }
            }
        }

        // 保存最高置信度的缺陷图像
        if (bestWrapper != null && bestResult != null) {
            Log.d(TAG, "开始保存最高置信度的缺陷图像，置信度: " + highestConfidence);
            saveDefectImage(bestWrapper, bestResult, decideResult, highestConfidence);
        } else {
            Log.e(TAG, "未找到合适的图像进行保存");
        }
    }

    private void saveDefectImage(DetectionWrapper wrapper, DetectResult detectResult,
                                 DecideResult decideResult, float confidence) {
        try {
            Log.d(TAG, "开始处理图像保存，缺陷类型: " + decideResult.defectType());

            Bitmap mutableBitmap = wrapper.getOriginalFrame().toBitmap(true,
                    wrapper.getOriginalFrame().width(),
                    wrapper.getOriginalFrame().height(),
                    Bitmap.Config.ARGB_8888).copy(Bitmap.Config.ARGB_8888, true);

            Log.d(TAG, "创建位图成功，大小: " + mutableBitmap.getWidth() + "x" + mutableBitmap.getHeight());

            // 创建画布和画笔
            Canvas canvas = new Canvas(mutableBitmap);
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(Color.RED);
            paint.setStrokeWidth(5);

            // 设置文本画笔
            Paint textPaint = new Paint();
            textPaint.setColor(Color.RED);
            textPaint.setTextSize(40);
            textPaint.setStyle(Paint.Style.FILL);

            // 绘制缺陷框和得分
            if (detectResult.getDetects() != null) {
                for (Detect detect : detectResult.getDetects()) {
                    // 获取图像实际尺寸
                    int imageWidth = mutableBitmap.getWidth();
                    int imageHeight = mutableBitmap.getHeight();

                    // 计算实际的像素坐标（中心点）
                    float centerX = detect.getX() * imageWidth;
                    float centerY = detect.getY() * imageHeight;

                    // 计算实际的像素尺寸
                    float width = detect.getW() * imageWidth;
                    float height = detect.getH() * imageHeight;

                    // 计算矩形的左上角和右下角坐标
                    float left = centerX - width / 2;
                    float top = centerY - height / 2;
                    float right = centerX + width / 2;
                    float bottom = centerY + height / 2;

                    // 绘制矩形框
                    canvas.drawRect(left, top, right, bottom, paint);

                    // 绘制中心点标记（可选）
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(centerX, centerY, 3, paint);
                    paint.setStyle(Paint.Style.STROKE);

                    Log.d(TAG, String.format("绘制缺陷框 - 中心点:(%.1f,%.1f), 尺寸:%.1fx%.1f",
                            centerX, centerY, width, height));

                    // 在矩形右侧绘制置信度得分
                    String scoreText = String.format("%.2f%%", detect.getScore() * 100);
                    canvas.drawText(scoreText, right + 10, centerY, textPaint);
                }
            }

            // 生成文件名
            String fileName = String.format("defect_%s_conf%.4f_%d.jpg",
                    decideResult.defectType(),
                    confidence,
                    System.currentTimeMillis());

            // 保存到相册
            String savedPath = MediaStore.Images.Media.insertImage(
                    context.getContentResolver(),
                    mutableBitmap,
                    fileName,
                    String.format("缺陷检测结果 - 类型:%s, 置信度:%.4f",
                            decideResult.defectType(),
                            confidence)
            );

            if (savedPath != null) {
                Log.d(TAG, "成功保存缺陷图像: " + fileName);
                Log.d(TAG, "保存路径: " + savedPath);

                // 发送广播通知图库更新
                context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE));
                Log.d(TAG, "已发送图库更新广播");

                // 发送停止检测命令
                EventBusUtils.post(new StopDetectionCommand("检测到缺陷"));
                Log.d(TAG, "已发送停止检测命令");

                // 跳转到缺陷显示界面
                Intent intent = new Intent(context, DefectStopActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  // 因为在非Activity上下文中启动Activity需要这个标志
                
                // 传递缺陷图片URI
                intent.putExtra("defect_image_uri", savedPath);
                
                // 传递缺陷详细信息
                intent.putExtra("defect_type", getDefectTypeDisplayName(decideResult.getMultiDefType().getName()));
                intent.putExtra("defect_confidence", confidence);
                intent.putExtra("defect_timestamp", System.currentTimeMillis());
                
                // 传递缺陷位置信息（找到最高置信度的检测框）
                if (detectResult != null && detectResult.getDetects() != null) {
                    for (Detect detect : detectResult.getDetects()) {
                        if (detect.getScore() == confidence) {
                            intent.putExtra("defect_x", detect.getX());
                            intent.putExtra("defect_y", detect.getY());
                            intent.putExtra("defect_width", detect.getW());
                            intent.putExtra("defect_height", detect.getH());
                            break;
                        }
                    }
                }
                
                // 传递各种缺陷类型的统计信息
                intent.putExtra("duanzhen_count", decideResult.getDuanzhenNum());
                intent.putExtra("feigen_count", decideResult.getFeigenNum());
                intent.putExtra("podong_count", decideResult.getPodongNum());
                intent.putExtra("tiny_count", decideResult.getTinyNum());
                
                context.startActivity(intent);
                Log.d(TAG, "已启动缺陷显示界面，传递缺陷信息: " + decideResult.getMultiDefType().getName());

            } else {
                Log.e(TAG, "保存图像失败: " + fileName);
            }

            // 释放资源
            mutableBitmap.recycle();
            Log.d(TAG, "已释放位图资源");

        } catch (Exception e) {
            Log.e(TAG, "保存缺陷图像失败: " + e.getMessage(), e);
        }
    }

    /**
     * 获取缺陷类型的中文显示名称
     */
    private String getDefectTypeDisplayName(String defectType) {
        switch (defectType) {
            case "DUANZHEN":
                return "断针";
            case "FEIGEN":
                return "飞根";
            case "PODONG":
                return "破洞";
            case "TINY":
                return "小缺陷";
            default:
                return defectType;
        }
    }

    public void release() {
        EventBusUtils.unregister(this);
        if (currentCycleResults != null) {
            currentCycleResults.clear();
            currentCycleResults = null;
        }
    }
}