package com.yuansheng.fabricdetect.java.hardware;

import android.util.Log;

/**
 * GPIO135控制类
 * 负责控制GPIO135引脚的电平状态，用于织布机控制
 */
public class Gpio135Control {
    private static final String TAG = "Gpio135Control";
    
    // GPIO参数配置
    private static final int GPIO_PIN = 135;  // GPIO135引脚
    
    private final GpioPwmManager gpioPwmManager;
    private boolean isInitialized = false;
    private boolean isHigh = false; // 当前电平状态
    
    // 标记是否已经初始化过硬件
    private static boolean hw135Initialized = false;
    
    public Gpio135Control() {
        gpioPwmManager = new GpioPwmManager();
    }
    
    /**
     * 初始化GPIO135控制
     * @return 是否初始化成功
     */
    public boolean initialize() {
        Log.d(TAG, "开始初始化GPIO135控制...");
        if (isInitialized) {
            Log.d(TAG, "GPIO135控制已经初始化过了");
            return true;
        }
        
        try {
            // 初始化硬件
            Log.d(TAG, "调用initHardware()...");
            boolean success = initHardware();
            if (!success) {
                Log.e(TAG, "GPIO135硬件初始化失败");
                return false;
            }
            
            // 注意：不在初始化时设置GPIO状态，由上层应用控制
            // 这样可以避免在应用启动时意外改变IO状态
            Log.d(TAG, "GPIO135硬件初始化完成，等待上层设置状态");
            
            isInitialized = true;
            Log.d(TAG, "GPIO135控制初始化成功");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "GPIO135控制初始化失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 初始化硬件，只需要执行一次
     */
    private boolean initHardware() {
        if (hw135Initialized) {
            return true;
        }
        
        // 设置GPIO输出模式
        boolean gpioSetup = gpioPwmManager.setGpioOutput(GPIO_PIN);
        if (!gpioSetup) {
            Log.e(TAG, "GPIO135设置失败");
            return false;
        }
        
        hw135Initialized = true;
        Log.d(TAG, "GPIO135硬件初始化成功");
        return true;
    }
    
    /**
     * 设置GPIO135为高电平（织布机启动）
     * @return 是否设置成功
     */
    public boolean setHigh() {
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            boolean success = gpioPwmManager.writeGpio(GPIO_PIN, true);
            if (success) {
                isHigh = true;
                Log.d(TAG, "GPIO135已设置为高电平（织布机启动）");
            } else {
                Log.e(TAG, "设置GPIO135为高电平失败");
            }
            return success;
        } catch (Exception e) {
            Log.e(TAG, "设置GPIO135为高电平异常: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 设置GPIO135为低电平（织布机停止）
     * @return 是否设置成功
     */
    public boolean setLow() {
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            boolean success = gpioPwmManager.writeGpio(GPIO_PIN, false);
            if (success) {
                isHigh = false;
                Log.d(TAG, "GPIO135已设置为低电平（织布机停止）");
            } else {
                Log.e(TAG, "设置GPIO135为低电平失败");
            }
            return success;
        } catch (Exception e) {
            Log.e(TAG, "设置GPIO135为低电平异常: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 设置GPIO135电平状态
     * @param high true为高电平（织布机启动），false为低电平（织布机停止）
     */
    public boolean setLevel(boolean high) {
        return high ? setHigh() : setLow();
    }
    
    /**
     * 获取当前电平状态
     * @return true为高电平，false为低电平
     */
    public boolean isHigh() {
        return isHigh;
    }
    
    /**
     * 获取GPIO引脚号
     */
    public int getGpioPin() {
        return GPIO_PIN;
    }
    
    /**
     * 释放资源
     */
    public void release() {
        if (isInitialized) {
            try {
                // 设置为低电平后释放
                setLow();
                isInitialized = false;
                Log.d(TAG, "GPIO135控制资源已释放");
            } catch (Exception e) {
                Log.e(TAG, "释放GPIO135控制资源失败: " + e.getMessage(), e);
            }
        }
    }
    
    /**
     * 完全释放硬件资源（应用退出时调用）
     */
    public void completeRelease() {
        release();
        if (hw135Initialized) {
            try {
                // 确保GPIO设置为低电平
                gpioPwmManager.writeGpio(GPIO_PIN, false);
                hw135Initialized = false;
                Log.d(TAG, "GPIO135硬件资源完全释放");
            } catch (Exception e) {
                Log.e(TAG, "完全释放GPIO135硬件资源失败: " + e.getMessage(), e);
            }
        }
    }
}
