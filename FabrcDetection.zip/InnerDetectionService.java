package com.iflytek.south.industry.android.model.engine;

import android.content.Context;
import android.util.Log;
import com.iflytek.south.industry.android.model.bo.CycleFramePredictData;
import com.iflytek.south.industry.android.core.enums.DefectType;
import com.yuansheng.fabricdetect.java.event.command.UpdateParamsCommand;
import com.yuansheng.fabricdetect.java.params.Params;
import com.yuansheng.fabricdetect.java.params.ParamsManager;
import com.yuansheng.fabricdetect.java.utils.EventBusUtils;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import java.util.LinkedList;
import java.util.Map;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class InnerDetectionService extends DetectionService {
    private static final String TAG = "InnerDetectionService";
    private static KaifuInfo kaifuInfo;
    private static DefectRegisterResult defectShield;
    private float speed = 0.3f, speedRange = 0.45f, halfSpeed, halfSpeedRange;
    private LinkedList<DecideResult> multiDecideResultQueue;
    private int numCycDef = 3;
    private ParamsManager paramsManager;
    private Context context;

    public InnerDetectionService(String modelPath, Context context) {
        super(modelPath, 1, "");
        this.context = context;
        init();
    }

    private void init() {
        multiDecideResultQueue = new LinkedList<>();
        paramsManager = ParamsManager.getInstance(context);
        EventBusUtils.register(this);
        Params params = paramsManager.getParams();
        UpdateSpeed(params.getDecideSpeed());
        UpdateRange(params.getDecideSpeedRange());
        numCycDef = params.getnumCycDef();
        initKaifuInfo();
        initDefectShield();
        try {
            buildDcdEngine();
            Log.d(TAG, "DCD引擎初始化成功");
        } catch (Exception e) {
            Log.e(TAG, "初始化DCD引擎失败: " + e.getMessage(), e);
        }
    }

    private void initKaifuInfo() {
        if (kaifuInfo == null) {
            Params params = paramsManager.getParams();
            int chouzhenWidth = params.getChouzhenWidth();
            boolean hasChouzhen = chouzhenWidth > 0;
            float mergeT = calculateMergeT(chouzhenWidth);
            kaifuInfo = new KaifuInfo(hasChouzhen, mergeT);
            Log.d(TAG, "初始化开幅信息: hasChouzhen=" + hasChouzhen + ", mergeT=" + mergeT);
        }
    }

    private float calculateMergeT(int chouzhenWidth) {
        if (chouzhenWidth == 0) return 0.0f;
        return new BigDecimal(0.05).multiply(new BigDecimal(chouzhenWidth))
                .add(new BigDecimal(0.02)).floatValue();
    }

    private void initDefectShield() {
        if (defectShield == null) {
            defectShield = new DefectRegisterResult(false, 0);
            Log.d(TAG, "初始化缺陷屏蔽: hasDefect=false, size=0");
        }
    }

    public void buildDcdEngine() {
        DcdEngineBuilder builder = new DcdEngineBuilder(context);
        if (!builder.build()) throw new IllegalStateException("初始化DCD决策引擎失败");
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onUpdateParamsCommand(UpdateParamsCommand command) {
        if (command == null || command.getParams() == null) return;
        Log.d(TAG, "检测服务接收到参数更新: " + command.getParams().toString());
        Map<String, Object> updatedParams = command.getParams();
        boolean needRebuildEngine = false, needUpdateSpeed = false, needUpdateCycles = false, needUpdateKaifu = false;
        if (updatedParams.containsKey("rollAnticlockwise") || updatedParams.containsKey("feigenThresh") ||
            updatedParams.containsKey("useFilter") || updatedParams.containsKey("noneKaifuThresh") ||
            updatedParams.containsKey("detectDuanzhen") || updatedParams.containsKey("maskScale") ||
            updatedParams.containsKey("gapThresh") || updatedParams.containsKey("positionThresh") ||
            updatedParams.containsKey("autoReduceKaifu") || updatedParams.containsKey("enablePodong2Duanzhen")) {
            needRebuildEngine = true;
        }
        if (updatedParams.containsKey("detectionSpeed") || updatedParams.containsKey("detectionSpeedRange") ||
            updatedParams.containsKey("decideSpeed") || updatedParams.containsKey("decideSpeedRange")) {
            needUpdateSpeed = true;
        }
        if (updatedParams.containsKey("cycleCount") || updatedParams.containsKey("numCycDef")) {
            needUpdateCycles = true;
        }
        if (updatedParams.containsKey("chouzhenWidth") || updatedParams.containsKey("multiChouzhenWide")) {
            needUpdateKaifu = true;
        }
        Params params = paramsManager.getParams();
        if (needUpdateSpeed) {
            UpdateSpeed(params.getDecideSpeed());
            UpdateRange(params.getDecideSpeedRange());
            Log.d(TAG, "更新检测速度参数: speed=" + speed + ", speedRange=" + speedRange);
        }
        if (needUpdateCycles) {
            numCycDef = params.getCycleCount();
            Log.d(TAG, "更新检测圈数: " + numCycDef);
            while (multiDecideResultQueue.size() > numCycDef) multiDecideResultQueue.poll();
        }
        if (needUpdateKaifu) updateKaifuInfo(params);
        if (needRebuildEngine) {
            Log.d(TAG, "DCD引擎参数已更新，重新构建引擎");
            try { buildDcdEngine(); } catch (Exception e) { Log.e(TAG, "重建DCD引擎失败: " + e.getMessage(), e); }
        }
    }

    private void updateKaifuInfo(Params params) {
        int chouzhenWidth = params.getChouzhenWidth();
        boolean hasChouzhen = chouzhenWidth > 0;
        float mergeT = calculateMergeT(chouzhenWidth);
        kaifuInfo = new KaifuInfo(hasChouzhen, mergeT);
        Log.d(TAG, "更新开幅信息: hasChouzhen=" + hasChouzhen + ", mergeT=" + mergeT);
        boolean needSpecialKaifu = chouzhenWidth >= 10 || params.isMultiChouzhenWide();
        if (needSpecialKaifu) {
            paramsManager.updateParam("decideSpeed", 0.15f);
            paramsManager.updateParam("decideSpeedRange", 0.5f);
            paramsManager.updateParam("autoReduceKaifu", false);
            Log.d(TAG, "启用特殊开幅设置: decideSpeed=0.15, decideSpeedRange=0.5, autoReduceKaifu=false");
        } else {
            paramsManager.resetParamToDefault("decideSpeed");
            paramsManager.resetParamToDefault("decideSpeedRange");
            paramsManager.resetParamToDefault("autoReduceKaifu");
            Log.d(TAG, "关闭特殊开幅设置，恢复默认参数");
        }
    }

    public void UpdateSpeed(float speed) {
        this.speed = speed;
        this.halfSpeed = new BigDecimal(String.valueOf(speed)).divide(new BigDecimal(2), RoundingMode.HALF_UP).floatValue();
        Log.d(TAG, "检测速度更新为: " + speed);
    }

    public void UpdateRange(float range) {
        this.speedRange = range;
        this.halfSpeedRange = new BigDecimal(String.valueOf(range)).divide(new BigDecimal(2), RoundingMode.HALF_UP).floatValue();
        Log.d(TAG, "检测速度范围更新为: " + range);
    }

    @Override
    public DecideResult doDecide(CycleFramePredictData data) {
        if (this.released) {
            Log.w(TAG, "引擎已释放");
            return new DecideResult(DefectType.NORMAL, DefectType.NORMAL, -1, -1);
        }
        float[][][] decideData = DetectionService.buildDecideData(data.getDataList());
        float decideSpeed = speed, decideSpeedRange = speedRange;
        boolean runSlow = false;
        if (runSlow) {
            decideSpeed = halfSpeed;
            decideSpeedRange = halfSpeedRange;
        }
        Log.d(TAG, String.format("执行决策: speed=%.2f, speedRange=%.2f, hasChouzhen=%b, mergeT=%.2f",
                decideSpeed, decideSpeedRange, kaifuInfo.isHasChouzhen(), kaifuInfo.getMergeT()));
        DecideResult result = decideInner(decideData, decideSpeed, decideSpeedRange, kaifuInfo, defectShield);
        ifDetectTiny(result);
        if (result != null) {
            result.addDecideParams("decide_speed", decideSpeed);
            result.addDecideParams("decide_speed_range", decideSpeedRange);
            decideDefTag(result);
            checkMultiDecideResult(result);
            Log.d(TAG, String.format("决策结果: 断针=%b(数量:%d), 飞根=%b(数量:%d), 破洞=%b(数量:%d), 小缺陷=%b(数量:%d)",
                    result.isDuanzhen(), result.getDuanzhenNum(),
                    result.isFeigen(), result.getFeigenNum(),
                    result.isPodong(), result.getPodongNum(),
                    result.isTiny(), result.getTinyNum()));
            Log.d(TAG, "断针关键帧: " + result.getDuanzhenKeyFrames().toString());
        }
        return result;
    }

    private void ifDetectTiny(DecideResult result) {
        if (result == null) return;
        Params params = paramsManager.getParams();
        if (result.isTiny() && !params.isDetectTiny()) {
            Log.d(TAG, "表面小微缺陷检出参数已关闭，屏蔽检出");
            result.setTiny(false);
            result.setTinyKeyFrames(null);  // 清空关键帧
            result.setTinyNum(0);           // 设置数量为0
        }
        if (result.isPodong() && !params.isDetectPodong()) {
            Log.d(TAG, "破损小微缺陷检出参数已关闭，屏蔽检出");
            result.setPodong(false);
            result.setPodongKeyFrames(null);  // 清空关键帧
            result.setPodongNum(0);           // 设置数量为0
        }
    }

    public native DecideResult decideInner(float[][][] data, float speed, float speedRange, KaifuInfo kaifuInfo, DefectRegisterResult defectShield);

    private void decideDefTag(DecideResult result) {
        if (result == null) return;
        boolean isFrameDiff = false;
        if (result.isException()) {
            if (result.getException() != DefectType.FRAME_DIFF.getCode()) {
                result.setDefType(DefectType.getByCode(result.getException()));
                return;
            }
            isFrameDiff = true;
        }
        DefectType defectType = result.isDuanzhen() ? DefectType.DUAN_ZHEN :
                (result.isFeigen() ? DefectType.FEI_GEN :
                (result.isPodong() ? DefectType.PO_DONG :
                (result.isTiny() ? DefectType.TINY :
                (isFrameDiff ? DefectType.FRAME_DIFF : DefectType.NORMAL))));
        result.setDefType(defectType);
    }

    private void checkMultiDecideResult(DecideResult result) {
        if (result == null) return;
        try {
            if (result.getDefType().getCode() < 0) {
                result.setMultiDefType(result.getDefType());
                return;
            }
            addMultiDecideResult(result);
            if (multiDecideResultQueue.size() < numCycDef) {
                result.setMultiDefType(DefectType.NORMAL);
                return;
            }
            if (result.getDefType() == DefectType.NORMAL) {
                result.setMultiDefType(DefectType.NORMAL);
                return;
            }
            boolean allDuanzhen = true, allFeigen = true, allPodong = true, allTiny = true;
            for (DecideResult dr : multiDecideResultQueue) {
                if (!dr.isDuanzhen()) allDuanzhen = false;
                if (!dr.isFeigen()) allFeigen = false;
                if (!dr.isPodong()) allPodong = false;
                if (!dr.isTiny()) allTiny = false;
            }
            DefectType multiDefType = DefectType.NORMAL;
            if (result.isDuanzhen() && allDuanzhen) {multiDefType = DefectType.DUAN_ZHEN;   multiDecideResultQueue.clear();}//multiDecideResultQueue.clear();
            else if (result.isFeigen() && allFeigen){ multiDefType = DefectType.FEI_GEN;    multiDecideResultQueue.clear();}//用于决策出具体缺陷后清除链表缓存中的decideresult
            else if (result.isPodong() && allPodong){ multiDefType = DefectType.PO_DONG;    multiDecideResultQueue.clear();}
            else if (result.isTiny() && allTiny)    {multiDefType = DefectType.TINY;        multiDecideResultQueue.clear();}
            result.setMultiDefType(multiDefType);
        } catch (Exception e) {
            Log.e(TAG, "缺陷多圈决策发生错误: " + e.getMessage(), e);
        }
    }

    private void addMultiDecideResult(DecideResult result) {
        if (result == null) return;
        while (multiDecideResultQueue.size() >= numCycDef) multiDecideResultQueue.poll();
        multiDecideResultQueue.offer(result);
    }

    public void setKaifuInfo(boolean hasChouzhen, float mergeT) {
        kaifuInfo = new KaifuInfo(hasChouzhen, mergeT);
        Log.d(TAG, "手动更新开幅信息: hasChouzhen=" + hasChouzhen + ", mergeT=" + mergeT);
    }

    public native void releaseDcd();

    @Override
    public void release() {
        synchronized (this) {
            EventBusUtils.unregister(this);
            super.release();
            try { releaseDcd(); Log.d(TAG, "DCD引擎资源已释放"); }
            catch (Exception e) { Log.e(TAG, "释放DCD引擎资源时发生异常: " + e.getMessage()); }
            kaifuInfo = null;
            defectShield = null;
            if (multiDecideResultQueue != null) {
                multiDecideResultQueue.clear();
                multiDecideResultQueue = null;
            }
            paramsManager = null;
            context = null;
        }
    }
}