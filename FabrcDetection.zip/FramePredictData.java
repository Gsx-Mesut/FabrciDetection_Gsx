/*
 * Decompiled with CFR 0.152.
 */
package com.iflytek.south.industry.android.context.engine;

import com.iflytek.south.industry.android.context.engine.FrameData;
import com.iflytek.south.industry.android.context.engine.Image;
import com.iflytek.south.industry.android.context.engine.ReferenceCounted;
import com.iflytek.south.industry.android.model.engine.DetectResult;

public class FramePredictData
extends FrameData {
    public DetectResult detectResult;
    public FrameData frameData;

    public FramePredictData(FrameData frameData, DetectResult detectResult) {
        super(null);
        this.frameData = frameData;
        this.detectResult = detectResult;
    }

    @Override
    public void destroy() {
        this.frameData.destroy();
    }

    public DetectResult getDetectResult() {
        return this.detectResult;
    }

    @Override
    public Image getImage() {
        return this.frameData.getImage();
    }

    public boolean hasVerticalDefect() {
        boolean bl;
        block1: {
            boolean bl2 = false;
            int n2 = 0;
            while (true) {
                bl = bl2;
                if (n2 >= this.detectResult.getDetects().size()) break block1;
                if (this.detectResult.getDetects().get(n2).getLabel() == 0 || this.detectResult.getDetects().get(n2).getLabel() == 3) break;
                ++n2;
            }
            bl = true;
        }
        return bl;
    }

    @Override
    public void onDestroy() {
        this.frameData.onDestroy();
    }

    @Override
    public void recycle() {
        this.frameData.recycle();
    }

    @Override
    public void release() {
        this.frameData.release();
    }

    @Override
    public ReferenceCounted retain() {
        synchronized (this) {
            ReferenceCounted referenceCounted = this.frameData.retain();
            return referenceCounted;
        }
    }
}

