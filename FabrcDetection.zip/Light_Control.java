package com.yuansheng.fabricdetect.java.hardware;

import android.util.Log;

/**
 * 灯光控制类 - 简化版
 * 负责控制灯光板的开关和亮度调节
 */
public class Light_Control {
    private static final String TAG = "Light_Control";
    
    // PWM参数配置
    private static final int PWM_CHIP = 4;      // PWM芯片编号
    private static final int PWM_CHANNEL = 0;   // PWM通道编号
    private static final int PWM_PERIOD = 100000;  // PWM周期，单位ns (20ms)
    
    // GPIO参数配置
    private static final int GPIO_LIGHT_SWITCH = 133;  // 灯光开关GPIO
    
    // PWM占空比范围（根据实际硬件特性调整）
    private static final float MIN_DUTY_PERCENT = 0.41f;  // 最低占空比 7.6M/20M 0.41f
    private static final float MAX_DUTY_PERCENT = 0.59f;  // 最高占空比 12.1M/20M  0.61f
    
    // 有效亮度范围
    private static final int EFFECTIVE_MIN = 0;    // 关灯
    private static final int EFFECTIVE_MAX = 62;   // 最大亮度(对应电流1.1A) 62
    
    // 亮度临界值
    private static final int LIGHT_THRESHOLD = 1;  // 当亮度>=1时开灯
    
    private final GpioPwmManager gpioPwmManager;
    private boolean isInitialized = false;
    private boolean isLightOn = false;
    private int currentIntensity = 30; // 默认亮度值
    
    // 标记是否已经初始化过硬件
    private static boolean hwInitialized = false;
    
    public Light_Control() {
        gpioPwmManager = new GpioPwmManager();
    }
    
    /**
     * 初始化灯光控制
     * @return 是否初始化成功
     */
    public boolean initialize() {
        if (isInitialized) {
            return true;
        }
        
        try {
            // 初始化硬件
            boolean success = initHardware();
            if (!success) {
                return false;
            }
            
            // 设置初始占空比
            int dutyNs = calculateDuty(currentIntensity);
            gpioPwmManager.setPwmDuty(PWM_CHIP, PWM_CHANNEL, dutyNs);
            
            isInitialized = true;
            Log.d(TAG, "灯光控制初始化成功");


            return true;
        } catch (Exception e) {
            Log.e(TAG, "灯光控制初始化失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 初始化硬件，只需要执行一次
     */
    private boolean initHardware() {
        if (hwInitialized) {
            return true;
        }
        
        // 导出GPIO和PWM
        boolean gpioSetup = gpioPwmManager.setGpioOutput(GPIO_LIGHT_SWITCH);
        if (!gpioSetup) {
            Log.e(TAG, "GPIO设置失败");
            return false;
        }
        
        boolean pwmExport = gpioPwmManager.exportPwm(PWM_CHIP, PWM_CHANNEL);
        if (!pwmExport) {
            Log.w(TAG, "PWM导出失败，尝试重新导出");
            gpioPwmManager.unexportPwm(PWM_CHIP, PWM_CHANNEL);
            pwmExport = gpioPwmManager.exportPwm(PWM_CHIP, PWM_CHANNEL);
            if (!pwmExport) {
                Log.e(TAG, "PWM导出失败");
                return false;
            }
        }
        
        // 设置PWM周期
        boolean periodSet = gpioPwmManager.setPwmPeriod(PWM_CHIP, PWM_CHANNEL, PWM_PERIOD);
        if (!periodSet) {
            Log.e(TAG, "设置PWM周期失败");
            return false;
        }
        
        hwInitialized = true;
        return true;
    }
    
    /**
     * 打开灯光
     */
    public boolean turnOn() {
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            // 设置高电平开灯
            gpioPwmManager.writeGpio(GPIO_LIGHT_SWITCH, true);
            // 启用PWM
            gpioPwmManager.enablePwm(PWM_CHIP, PWM_CHANNEL, true);
            isLightOn = true;
            Log.d(TAG, "灯光已打开");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "打开灯光失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 关闭灯光
     */
    public boolean turnOff() {
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            // 关闭PWM
            gpioPwmManager.enablePwm(PWM_CHIP, PWM_CHANNEL, false);
            // 设置低电平关灯
            gpioPwmManager.writeGpio(GPIO_LIGHT_SWITCH, false);
            isLightOn = false;
            Log.d(TAG, "灯光已关闭");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "关闭灯光失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 设置灯光亮度 (0-100，实际会映射到有效亮度范围)
     * 根据实际观察:
     * - 当亮度=0时，灯光关闭
     * - 当亮度>=1时，灯光开启，并根据亮度值调节亮度
     */
    public boolean setIntensity(int intensity) {
        // 将传入的亮度值 (0-100) 限制到标准范围
        int limitedIntensity = Math.max(0, Math.min(100, intensity));
        
        // 记录用户设定的亮度值
        currentIntensity = limitedIntensity;
        
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            // 如果亮度为0，始终确保关闭灯光
            if (limitedIntensity == 0) {
                Log.d(TAG, "设置亮度为0，关闭灯光");
                return turnOff();
            } else {
                // 亮度大于0时，开灯并设置亮度
                // 将用户设定的亮度值 (1-100) 映射到有效亮度范围 (1-62)
                int effectiveIntensity = mapToEffectiveRange(limitedIntensity);
                
                // 确保灯光开启
                if (!isLightOn) {
                    turnOn();
                }
                
                // 设置PWM占空比
                int dutyNs = calculateDuty(effectiveIntensity);
                boolean result = gpioPwmManager.setPwmDuty(PWM_CHIP, PWM_CHANNEL, dutyNs);
                
                if (result) {
                    Log.d(TAG, "设置亮度: 原始=" + limitedIntensity + ", 有效=" + effectiveIntensity + ", 占空比=" + dutyNs + "ns");
                }
                return result;
            }
        } catch (Exception e) {
            Log.e(TAG, "设置亮度失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 将标准亮度值 (0-100) 映射到有效亮度范围 (0-62)
     */
    private int mapToEffectiveRange(int standardIntensity) {
        // 0保持为0(关灯)，其他值映射到1-62
        if (standardIntensity <= 0) return 0;
        
        // 将1-100映射到1-62
        if (standardIntensity >= 100) return EFFECTIVE_MAX;
        
        return 1 + (standardIntensity - 1) * (EFFECTIVE_MAX - 1) / 99;
    }
    
    /**
     * 计算PWM占空比
     * @param intensity 有效亮度值 (0-62)
     * @return 占空比时间(ns)
     */
    private int calculateDuty(int intensity) {
        // 如果强度为0，返回0占空比（关闭）
        if (intensity <= 0) return 0;
        
        // 根据实际硬件特性，将亮度线性映射到占空比
        // 亮度越大，占空比越大（与硬件特性相符）
        float normalizedIntensity = (float)(intensity) / EFFECTIVE_MAX;
        float dutyPercent = MIN_DUTY_PERCENT + normalizedIntensity * (MAX_DUTY_PERCENT - MIN_DUTY_PERCENT);
        
        // 确保占空比在有效范围内
        dutyPercent = Math.max(MIN_DUTY_PERCENT, Math.min(MAX_DUTY_PERCENT, dutyPercent));
        
        return (int) (PWM_PERIOD * dutyPercent);
    }
    
    /**
     * 获取当前亮度
     */
    public int getCurrentIntensity() {
        return currentIntensity;
    }
    
    /**
     * 灯光是否打开
     */
    public boolean isLightOn() {
        return isLightOn;
    }
    
    /**
     * 释放资源
     */
    public void release() {
        if (isInitialized) {
            turnOff();
            isInitialized = false;
        }
    }
    
    /**
     * 完全释放硬件资源（应用退出时调用）
     */
    public void completeRelease() {
        release();
        if (hwInitialized) {
            try {
                // 确保PWM关闭
                gpioPwmManager.enablePwm(PWM_CHIP, PWM_CHANNEL, false);
                // 取消PWM导出
                gpioPwmManager.unexportPwm(PWM_CHIP, PWM_CHANNEL);
                hwInitialized = false;
            } catch (Exception e) {
                Log.e(TAG, "完全释放资源失败: " + e.getMessage(), e);
            }
        }
    }
}
