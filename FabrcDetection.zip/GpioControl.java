package com.yuansheng.fabricdetect.java.hardware;

import android.util.Log;

/**
 * GPIO控制类
 * 负责控制GPIO134引脚的电平状态
 */
public class GpioControl {
    private static final String TAG = "GpioControl";
    
    // GPIO参数配置
    private static final int GPIO_PIN = 134;  // GPIO134引脚
    
    private final GpioPwmManager gpioPwmManager;
    private boolean isInitialized = false;
    private boolean isHigh = false; // 当前电平状态
    
    // 标记是否已经初始化过硬件
    private static boolean hwInitialized = false;
    
    public GpioControl() {
        gpioPwmManager = new GpioPwmManager();
    }
    
    /**
     * 初始化GPIO控制
     * @return 是否初始化成功
     */
    public boolean initialize() {
        if (isInitialized) {
            return true;
        }
        
        try {
            // 初始化硬件
            boolean success = initHardware();
            if (!success) {
                return false;
            }
            
            // 设置初始状态为低电平
            gpioPwmManager.writeGpio(GPIO_PIN, false);
            isHigh = false;
            
            isInitialized = true;
            Log.d(TAG, "GPIO控制初始化成功");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "GPIO控制初始化失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 初始化硬件，只需要执行一次
     */
    private boolean initHardware() {
        if (hwInitialized) {
            return true;
        }
        
        // 设置GPIO输出模式
        boolean gpioSetup = gpioPwmManager.setGpioOutput(GPIO_PIN);
        if (!gpioSetup) {
            Log.e(TAG, "GPIO134设置失败");
            return false;
        }
        
        hwInitialized = true;
        Log.d(TAG, "GPIO134硬件初始化成功");
        return true;
    }
    
    /**
     * 设置GPIO134为高电平
     */
    public boolean setHigh() {//高电平报警
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            boolean result = gpioPwmManager.writeGpio(GPIO_PIN, true);
            if (result) {
                isHigh = true;
                Log.d(TAG, "GPIO134设置为高电平");
            } else {
                Log.e(TAG, "设置GPIO134高电平失败");
            }
            return result;
        } catch (Exception e) {
            Log.e(TAG, "设置GPIO134高电平失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 设置GPIO134为低电平
     */
    public boolean setLow() {
        if (!isInitialized && !initialize()) {
            return false;
        }
        
        try {
            boolean result = gpioPwmManager.writeGpio(GPIO_PIN, false);
            if (result) {
                isHigh = false;
                Log.d(TAG, "GPIO134设置为低电平");
            } else {
                Log.e(TAG, "设置GPIO134低电平失败");
            }
            return result;
        } catch (Exception e) {
            Log.e(TAG, "设置GPIO134低电平失败: " + e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * 设置GPIO电平状态
     * @param high true为高电平，false为低电平
     */
    public boolean setLevel(boolean high) {
        return high ? setHigh() : setLow();
    }
    
    /**
     * 获取当前电平状态
     * @return true为高电平，false为低电平
     */
    public boolean isHigh() {
        return isHigh;
    }
    
    /**
     * 获取GPIO引脚号
     */
    public int getGpioPin() {
        return GPIO_PIN;
    }
    
    /**
     * 释放资源
     */
    public void release() {
        if (isInitialized) {
            try {
                // 设置为低电平后释放
                setLow();
                isInitialized = false;
                Log.d(TAG, "GPIO控制资源已释放");
            } catch (Exception e) {
                Log.e(TAG, "释放GPIO控制资源失败: " + e.getMessage(), e);
            }
        }
    }
    
    /**
     * 完全释放硬件资源（应用退出时调用）
     */
    public void completeRelease() {
        release();
        if (hwInitialized) {
            try {
                // 确保GPIO设置为低电平
                gpioPwmManager.writeGpio(GPIO_PIN, false);
                hwInitialized = false;
                Log.d(TAG, "GPIO134硬件资源完全释放");
            } catch (Exception e) {
                Log.e(TAG, "完全释放GPIO硬件资源失败: " + e.getMessage(), e);
            }
        }
    }
}