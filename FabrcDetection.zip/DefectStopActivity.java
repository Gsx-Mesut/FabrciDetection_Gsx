package com.yuansheng.fabricdetect.java;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.yuansheng.fabricdetect.R;
import com.yuansheng.fabricdetect.java.hardware.HardwareManager;
import com.yuansheng.fabricdetect.java.params.ParamsManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DefectStopActivity extends AppCompatActivity {
    private static final String TAG = "DefectStopActivity";
    
    // UI组件
    private ImageView ivDefectImage;
    private TextView tvDefectType;
    private TextView tvDefectConfidence;
    private TextView tvDefectPosition;
    private TextView tvDefectTime;
    private Button btnBackToMain;
    
    // 硬件管理器
    private HardwareManager hardwareManager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_defect_stop);

        // 初始化硬件管理器
        hardwareManager = HardwareManager.getInstance(this);
        
        // 缺陷上报界面显示时启动报警灯（GPIO134为高电平）
        if (hardwareManager != null) {
            hardwareManager.setGpio134High();
            Log.d(TAG, "缺陷上报界面启动，设置GPIO134为高电平（报警灯开启）");
        }

        // 初始化UI组件
        initViews();
        
        // 获取和显示缺陷信息
        loadDefectInfo();
    }
    
    private void initViews() {
        ivDefectImage = findViewById(R.id.ivDefectImage);
        tvDefectType = findViewById(R.id.tvDefectType);
        tvDefectConfidence = findViewById(R.id.tvDefectConfidence);
        tvDefectPosition = findViewById(R.id.tvDefectPosition);
        tvDefectTime = findViewById(R.id.tvDefectTime);
        btnBackToMain = findViewById(R.id.btnBackToMain);
        
        // 返回主界面按钮点击事件
        btnBackToMain.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }
    
    private void loadDefectInfo() {
        Intent intent = getIntent();
        
        // 获取传递过来的缺陷信息
        String imageUri = intent.getStringExtra("defect_image_uri");
        String defectType = intent.getStringExtra("defect_type");
        float defectConfidence = intent.getFloatExtra("defect_confidence", 0.0f);
        long defectTimestamp = intent.getLongExtra("defect_timestamp", System.currentTimeMillis());
        
        // 获取缺陷位置信息
        float defectX = intent.getFloatExtra("defect_x", 0.0f);
        float defectY = intent.getFloatExtra("defect_y", 0.0f);
        float defectWidth = intent.getFloatExtra("defect_width", 0.0f);
        float defectHeight = intent.getFloatExtra("defect_height", 0.0f);
        
        // 获取各种缺陷类型的统计信息
        int duanzhenCount = intent.getIntExtra("duanzhen_count", 0);
        int feigenCount = intent.getIntExtra("feigen_count", 0);
        int podongCount = intent.getIntExtra("podong_count", 0);
        int tinyCount = intent.getIntExtra("tiny_count", 0);
        
        // 显示缺陷图片
        if (imageUri != null) {
            try {
                Uri uri = Uri.parse(imageUri);
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                ivDefectImage.setImageBitmap(bitmap);
                Log.d(TAG, "成功加载缺陷图片: " + imageUri);
            } catch (Exception e) {
                Log.e(TAG, "加载缺陷图片失败: " + e.getMessage(), e);
                Toast.makeText(this, "加载缺陷图片失败", Toast.LENGTH_SHORT).show();
            }
        }
        
        // 显示缺陷类型
        if (defectType != null) {
            tvDefectType.setText("缺陷类型: " + defectType);
            
            // 根据缺陷类型显示详细统计
            StringBuilder detailInfo = new StringBuilder();
            if (duanzhenCount > 0) detailInfo.append("断针:").append(duanzhenCount).append("个 ");
            if (feigenCount > 0) detailInfo.append("飞根:").append(feigenCount).append("个 ");
            if (podongCount > 0) detailInfo.append("破洞:").append(podongCount).append("个 ");
            if (tinyCount > 0) detailInfo.append("小缺陷:").append(tinyCount).append("个 ");
            
            if (detailInfo.length() > 0) {
                tvDefectType.setText(tvDefectType.getText() + "\n(" + detailInfo.toString().trim() + ")");
            }
        } else {
            tvDefectType.setText("缺陷类型: 未知");
        }
        
        // 显示置信度
        if (defectConfidence > 0) {
            tvDefectConfidence.setText(String.format("置信度: %.2f%%", defectConfidence * 100));
        } else {
            tvDefectConfidence.setText("置信度: 未知");
        }
        
        // 显示缺陷位置（归一化坐标转换为百分比）
        if (defectX > 0 && defectY > 0) {
            tvDefectPosition.setText(String.format("缺陷位置: (%.1f%%, %.1f%%) 尺寸: %.1f%% × %.1f%%", 
                    defectX * 100, defectY * 100, defectWidth * 100, defectHeight * 100));
        } else {
            tvDefectPosition.setText("缺陷位置: 未知");
        }
        
        // 显示检测时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String timeString = sdf.format(new Date(defectTimestamp));
        tvDefectTime.setText("检测时间: " + timeString);
        
        Log.d(TAG, String.format("缺陷信息加载完成 - 类型:%s, 置信度:%.4f, 位置:(%.4f,%.4f)", 
                defectType, defectConfidence, defectX, defectY));
    }

    @Override
    protected void onDestroy() {
        // 退出缺陷上报界面时关闭报警灯（GPIO134为低电平）
        if (hardwareManager != null) {
            hardwareManager.setGpio134Low();
            Log.d(TAG, "缺陷上报界面退出，设置GPIO134为低电平（报警灯关闭）");
        }
        
        super.onDestroy();
    }

    public static class FabricTypeActivity extends AppCompatActivity {
        private static final String TAG = "FabricTypeActivity";
        private ParamsManager paramsManager;
        private RadioGroup fabricTypeGroup;
        private Button btnConfirm;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_fabric_type);

            paramsManager = ParamsManager.getInstance(this);

            initViews();
            initValues();
            setupListeners();

        }

        private void initViews() {
            fabricTypeGroup = findViewById(R.id.fabric_type_group);
            btnConfirm = findViewById(R.id.btn_confirm);
            Button btnBack = findViewById(R.id.btn_back);
            btnBack.setOnClickListener(v -> onBackPressed());
        }

        private void initValues() {
            String fabricType = paramsManager.getParams().getParam("fabricType", "plain");
            int radioButtonId = R.id.rb_plain; // 默认选中平纹

            if ("plain".equals(fabricType)) {
                radioButtonId = R.id.rb_plain;
            } else if ("hoodie".equals(fabricType)) {
                radioButtonId = R.id.rb_hoodie;
            } else if ("rib".equals(fabricType)) {
                radioButtonId = R.id.rb_rib;
            } else if ("pique".equals(fabricType)) {
                radioButtonId = R.id.rb_pique;
            } else if ("stripe".equals(fabricType)) {
                radioButtonId = R.id.rb_stripe;
            } else if ("other".equals(fabricType)) {
                radioButtonId = R.id.rb_other;
            }

            fabricTypeGroup.check(radioButtonId);
        }

        private void setupListeners() {
            btnConfirm.setOnClickListener(v -> {
                String fabricType;
                boolean isDMmodel;
                boolean isKJTModel;
                int checkedId = fabricTypeGroup.getCheckedRadioButtonId();

                // 根据选择设置模型参数
                if (checkedId == R.id.rb_plain || checkedId == R.id.rb_hoodie ||
                        checkedId == R.id.rb_pique || checkedId == R.id.rb_other) {
                    isDMmodel = true;
                    isKJTModel = false;
                } else if (checkedId == R.id.rb_stripe || checkedId == R.id.rb_rib) {
                    isDMmodel = false;
                    isKJTModel = true;
                } else {
                    isDMmodel = true; // 默认值
                    isKJTModel = false;
                }

                // 设置布料类型
                if (checkedId == R.id.rb_plain) {
                    fabricType = "plain";
                } else if (checkedId == R.id.rb_hoodie) {
                    fabricType = "hoodie";
                } else if (checkedId == R.id.rb_rib) {
                    fabricType = "rib";
                } else if (checkedId == R.id.rb_pique) {
                    fabricType = "pique";
                } else if (checkedId == R.id.rb_stripe) {
                    fabricType = "stripe";
                } else if (checkedId == R.id.rb_other) {
                    fabricType = "other";
                } else {
                    fabricType = "plain"; // 默认值
                }

                // 更新参数
                Map<String, Object> newParams = new HashMap<>();
                newParams.put("fabricType", fabricType);
                newParams.put("DMmodel", isDMmodel);
                newParams.put("KJTModel", isKJTModel);
                paramsManager.updateParams(newParams);

                // 添加日志
                Log.d(TAG, "模型参数更新 - DMmodel: " + isDMmodel + ", KJTModel: " + isKJTModel);

                Toast.makeText(this, "布料类型设置成功", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }
}