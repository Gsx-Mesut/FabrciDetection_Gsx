package com.iflytek.south.industry.android.camera.uvc;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.util.Log;
import android.view.Surface;

import com.iflytek.south.industry.android.camera.Camera;
import com.iflytek.south.industry.android.camera.core.CameraCallback;
import com.iflytek.south.industry.android.camera.core.CameraOpenFailedException;
import com.iflytek.south.industry.android.context.engine.Image;
import com.iflytek.south.industry.android.utils.ImageUtil;
import com.serenegiant.usb.IFrameCallback;
import com.serenegiant.usb.USBMonitor;
import com.serenegiant.usb.UVCCamera;
import com.yuansheng.fabricdetect.java.camera.CameraParam;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * UVC相机实现，基于saki4510t的UVCCamera库
 * 实现CallbackCamera接口，支持UVC摄像头的连接、拍照、释放等操作
 */
public class UVCCameraAdapter implements Camera {
    private static final String TAG = "UVCCameraImpl";
    
    private Context context;
    private USBMonitor usbMonitor;
    private UVCCamera camera;
    private Surface previewSurface;
    private boolean isConnected = false;
    private CountDownLatch connectLatch;
    private CameraOpenFailedException connectException = null;
    private boolean isPreviewActive = false;
    
    // 修改回调队列类型
    private final ConcurrentLinkedDeque<CameraCallback> callbackDeque = new ConcurrentLinkedDeque<>();
    
    // 预览分辨率
    private int frameWidth = 1280;
    private int frameHeight = 1024;
    private int frameFormat = UVCCamera.FRAME_FORMAT_MJPEG; // MJPEG格式通常性能更好
    
    // 修改USB设备监听器
    private final USBMonitor.OnDeviceConnectListener deviceConnectListener = new USBMonitor.OnDeviceConnectListener() {
        @Override
        public void onAttach(UsbDevice device) {
            Log.i(TAG, "USB设备已连接: " + device.getDeviceName());
            requestPermission(device);
        }

        @Override
        public void onDettach(UsbDevice device) {
            Log.i(TAG, "USB设备已断开: " + device.getDeviceName());
            isConnected = false;
            isPreviewActive = false;
            
            // 通知所有回调
            for (CameraCallback callback : callbackDeque) {
                callback.onDisconnected(device);
            }
        }

        @Override
        public void onConnect(UsbDevice device, USBMonitor.UsbControlBlock ctrlBlock, boolean createNew) {
            Log.i(TAG, "USB设备已获得权限并连接: " + device.getDeviceName());
            try {
                openCamera(ctrlBlock);
                connectLatch.countDown();
                
                // 通知所有回调
                for (CameraCallback callback : callbackDeque) {
                    callback.onOpened(device);
                }
            } catch (Exception e) {
                connectException = new CameraOpenFailedException("打开相机失败: " + e.getMessage(), e);
                connectLatch.countDown();
                Log.e(TAG, "打开相机失败", e);
                
                // 通知所有回调
                for (CameraCallback callback : callbackDeque) {
                    callback.onError(device, null);
                }
            }
        }

        @Override
        public void onDisconnect(UsbDevice device, USBMonitor.UsbControlBlock ctrlBlock) {
            Log.i(TAG, "USB设备已断开连接: " + device.getDeviceName());
            isConnected = false;
            isPreviewActive = false;
            releaseCamera();
            
            // 通知所有回调
            for (CameraCallback callback : callbackDeque) {
                callback.onDisconnected(device);
            }
        }

        @Override
        public void onCancel(UsbDevice device) {
            Log.e(TAG, "USB设备权限被拒绝: " + device.getDeviceName());
            connectException = new CameraOpenFailedException("USB设备权限被拒绝");
            connectLatch.countDown();
            
            // 通知所有回调
            for (CameraCallback callback : callbackDeque) {
                callback.onError(device, null);
            }
        }
    };
    
    /**
     * 构造函数
     * 
     * @param context 上下文
     */
    public UVCCameraAdapter(Context context) {
        this.context = context;
        this.usbMonitor = new USBMonitor(context, deviceConnectListener);
    }

    /**
     * 连接相机
     * 注册USB监听器并开始检测USB设备
     * 
     * @throws CameraOpenFailedException 相机打开失败时抛出
     */
    @Override
    public void connect() throws CameraOpenFailedException {
        if (usbMonitor != null && !usbMonitor.isRegistered()) {
            // 初始化连接等待锁
            connectLatch = new CountDownLatch(1);
            connectException = null;
            
            // 确保先释放所有资源
            releaseCamera();
            
            // 延迟100ms确保之前的资源释放操作完成
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            usbMonitor.register();
            
            // 等待连接结果
            try {
                // 等待最多10秒
                boolean completed = connectLatch.await(10, TimeUnit.SECONDS);
                if (!completed) {
                    throw new CameraOpenFailedException("连接相机超时");
                }
                if (connectException != null) {
                    throw connectException;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new CameraOpenFailedException("连接过程被中断", e);
            }
        } else if (usbMonitor != null && isConnected) {
            Log.i(TAG, "相机已连接，无需重复操作");
        } else {
            throw new CameraOpenFailedException("无法初始化USB监视器");
        }
    }
    
    /**
     * 请求USB设备权限
     * 
     * @param device USB设备
     */
    private void requestPermission(UsbDevice device) {
        if (usbMonitor != null) {
            usbMonitor.requestPermission(device);
        }
    }
    
    /**
     * 打开相机并设置预览
     * 
     * @param ctrlBlock USB控制块
     * @throws Exception 打开相机失败时抛出
     */
    private void openCamera(USBMonitor.UsbControlBlock ctrlBlock) throws Exception {
        Log.i(TAG, "开始打开相机...");
        try {
            camera = new UVCCamera();
            Log.i(TAG, "尝试打开UVC设备...");
            camera.open(ctrlBlock);
            Log.i(TAG, "UVC设备打开成功");
            for (CameraCallback callback : callbackDeque) {
                callback.onOpened(this);
            }

            // 设置预览尺寸
            Log.i(TAG, "设置预览尺寸: " + frameWidth + "x" + frameHeight + ", 格式: " + frameFormat);
            camera.setPreviewSize(frameWidth, frameHeight, frameFormat);

            // 设置帧回调
            Log.i(TAG, "设置帧回调...");
            camera.setFrameCallback(mFrameCallback, UVCCamera.PIXEL_FORMAT_YUV420SP);

            // 成功打开相机，但不立即设置Surface，将在startPreview中设置
            isConnected = true;
            isPreviewActive = false; // 重置预览状态
            camera.updateCameraParams();
            Log.i(TAG, "相机初始化完成，等待设置预览Surface");
        } catch (Exception e) {
            Log.e(TAG, "打开相机过程中出现异常: " + e.getMessage(), e);
            releaseCamera();
            throw e;
        }
    }
    
    /**
     * 启动预览
     * 如果预览Surface已设置，则启动预览
     */
    public void startPreview() {
        if (camera != null && isConnected) {
            try {
                if (previewSurface != null) {
                    Log.i(TAG, "设置预览Surface并启动预览...");

                    // 关键修复：重新设置帧回调！
                    Log.i(TAG, "重新设置帧回调...");
                    camera.setFrameCallback(mFrameCallback, UVCCamera.PIXEL_FORMAT_YUV420SP);


                    camera.setPreviewDisplay(previewSurface);
                    camera.startPreview();
                    isPreviewActive = true; // 更新预览状态
                    Log.i(TAG, "预览启动成功");
                } else {
                    Log.e(TAG, "预览Surface未设置，无法启动预览");
                }
            } catch (Exception e) {
                Log.e(TAG, "启动预览失败: " + e.getMessage(), e);
                isPreviewActive = false; // 确保状态正确
            }
        } else {
            Log.e(TAG, "相机未初始化或未连接，无法启动预览");
        }
    }
    
    /**
     * 停止预览
     */
    public void stopPreview() {
        if (camera != null && isConnected) {
            try {
                Log.i(TAG, "停止预览...");

                // 关键修复：先清除帧回调，避免JNI崩溃
                camera.setFrameCallback(null, 0);

                // 等待一小段时间确保native线程处理完毕
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

                camera.stopPreview();
                isPreviewActive = false; // 更新预览状态
                Log.i(TAG, "预览已停止");
            } catch (Exception e) {
                Log.e(TAG, "停止预览失败: " + e.getMessage(), e);
                isPreviewActive = false; // 确保状态正确
            }
        }
    }
    
    /**
     * 检查相机是否已连接
     * 
     * @return 是否已连接
     */
    @Override
    public boolean isConnect() {
        return isConnected && camera != null;
    }
    
    /**
     * 释放相机资源
     */
    private void releaseCamera() {
        stopPreview(); // 先停止预览

        if (camera != null) {
            try {
                try {
                    camera.close();
                } catch (Exception e) {
                    Log.e(TAG, "关闭相机失败", e);
                }
                try {
                    camera.destroy();
                } catch (Exception e) {
                    Log.e(TAG, "销毁相机资源失败", e);
                }
            } catch (Exception e) {
                Log.e(TAG, "释放相机资源失败", e);
            } finally {
                camera = null;
            }
        }
        isConnected = false;
        isPreviewActive = false; // 重置预览状态
    }
    
    /**
     * 释放所有资源（包括相机、USB监视器、预览Surface等）
     */
    @Override
    public void release() {
        // 先释放相机资源
        releaseCamera();
        
        // 释放USB监视器
        if (usbMonitor != null) {
            try {
                if (usbMonitor.isRegistered()) {
                    usbMonitor.unregister();
                }
                usbMonitor.destroy();
            } catch (Exception e) {
                Log.e(TAG, "释放USB监视器资源失败", e);
            } finally {
                usbMonitor = null;
            }
        }
        
        // 清空预览Surface
        previewSurface = null;
        isConnected = false;
        isPreviewActive = false; // 重置预览状态
    }
    
    /**
     * 视频帧回调接口
     * 用于处理UVCCamera输出的视频帧
     */
    private final IFrameCallback mFrameCallback = new IFrameCallback() {
        @Override
        public void onFrame(ByteBuffer frame) {
            // 将UVC相机的帧数据转换为Image对象
            Image image = convertFrameToImage(frame);
            if (image != null) {
                for (CameraCallback callback : callbackDeque) {
                    callback.onImageAvailable(image);
                }
            }
        }
    };
    
    /**
     * 设置预览Surface
     * 
     * @param surface 预览Surface
     */
    @Override
    public void setPreviewSurface(final Surface surface) {
        this.previewSurface = surface;
        
        // 如果相机已经连接，尝试启动预览
        if (isConnected && camera != null && surface != null) {
            try {
                camera.setPreviewDisplay(surface);
                // 如果预览没有启动，则启动预览
//                if (!isPreviewActive) {
//                    camera.startPreview();
//                    isPreviewActive = true; // 更新预览状态
//                }
            } catch (Exception e) {
                Log.e(TAG, "设置预览Surface失败: " + e.getMessage(), e);
            }
        }
    }

    /**
     * 使用通用参数设置方法
     * 通过参数类型和值统一设置相机效果参数
     *
     * @param paramType 参数类型ID，参考ParamType枚举ordinal值
     * @param value 参数值，根据不同参数类型需要对应不同的数据类型
     */
    public void setEffectParams(CameraParam.ParamType paramType, Object value) {
        if (!isConnected || camera == null) return;
        
        try {
            // 将Object类型的value转换为int
            int intValue;
            if (value instanceof Integer) {
                intValue = (Integer) value;
            } else if (value instanceof Number) {
                intValue = ((Number) value).intValue();
            } else {
                Log.w(TAG, "无法转换参数值为int类型: " + value);
                return;
            }
            
            camera.setEffectParams((int)paramType.getValue(), intValue);
        } catch (Exception e) {
            Log.e(TAG, "设置参数失败: " + e.getMessage(), e);
        }
    }

    /**
     * 获取UVC相机支持的参数列表
     * @return UVC相机支持的参数列表
     */
    public List<CameraParam> getSupportedParams() {
        camera.updateCameraParams();

        List<CameraParam> params = new ArrayList<>();
        List<UVCCamera.UVCEffect> effects = camera.getEffects();

        for (UVCCamera.UVCEffect effect : effects) {
            CameraParam.ParamType type = getParamTypeFromId(effect.id);
            int minValue = effect.maxValue == effect.minValue ? 0 : effect.minValue;
            int maxValue = effect.maxValue == effect.minValue ? 1 : effect.maxValue;
            boolean isSupport = effect.isSupport;   // todo 确认uvc返回的效果support标识有效
            if (type != null) {
                params.add(new CameraParam(
                        type,
                        effect.name,
                        isSupport,
                        minValue,
                        maxValue,
                        effect.defValue,
                        effect.defValue  // 当前值初始化为默认值
                ));
                Log.i(TAG, "支持的参数: " + effect.name + ", min: " + effect.minValue + ", max: " + effect.maxValue + ", def: " + effect.defValue);
            }
        }
        return params;
    }

    /**
     * 根据ID获取对应的ParamType枚举
     * @param id UVC效果ID
     * @return 对应的ParamType枚举，如果找不到则返回null
     */
    private CameraParam.ParamType getParamTypeFromId(int id) {
        for (CameraParam.ParamType type : CameraParam.ParamType.values()) {
            if (type.getValue() == id) {
                return type;
            }
        }
        Log.w(TAG, "未找到对应的ParamType，ID: " + id);
        return null;
    }

    @Override
    public void pushCameraCallback(CameraCallback callback) {
        if (callback != null) {
            callbackDeque.push(callback);
        }
    }

    @Override
    public void removeCameraCallback(CameraCallback callback) {
        if (callback != null) {
            callbackDeque.remove(callback);
        }
    }

    @Override
    public Collection<CameraCallback> getCameraCallbacks() {
        return callbackDeque;
    }

    @Override
    public void startRepeatingCapture() {
        if (camera != null && isConnected) {
            try {
                startPreview();
            } catch (Exception e) {
                Log.e(TAG, "开始连续捕获失败", e);
            }
        }
    }

    @Override
    public void stopRepeatingCapture() {
        if (camera != null && isConnected) {
            try {
                stopPreview();
            } catch (Exception e) {
                Log.e(TAG, "停止连续捕获失败", e);
            }
        }
    }

    // 添加帧数据转换方法
    private Image convertFrameToImage(ByteBuffer frame) {
        return ImageUtil.byteBufferToImage(frameWidth, frameHeight, frame, 1, false);
    }

    @Override
    public boolean getIsPreviewActive() {
        return isPreviewActive;
    }
} 