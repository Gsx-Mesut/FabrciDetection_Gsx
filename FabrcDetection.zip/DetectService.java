package com.yuansheng.fabricdetect.java.detection;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.provider.MediaStore;
import android.util.Log;

import com.iflytek.south.industry.android.camera.core.DirectFrame;
import com.iflytek.south.industry.android.context.engine.FrameData;
import com.iflytek.south.industry.android.context.engine.FramePredictData;
import com.iflytek.south.industry.android.context.engine.Image;
import com.iflytek.south.industry.android.model.engine.Detect;
import com.iflytek.south.industry.android.model.engine.DetectResult;
import com.iflytek.south.industry.android.model.engine.DetectionService;
import com.yuansheng.fabricdetect.java.DefectStopActivity;
import com.yuansheng.fabricdetect.java.decide.DecisionResultEvent;
import com.yuansheng.fabricdetect.java.event.command.StartDetectionCommand;
import com.yuansheng.fabricdetect.java.event.command.StopDetectionCommand;
import com.yuansheng.fabricdetect.java.event.command.SwitchModelCommand;
import com.yuansheng.fabricdetect.java.event.command.UpdateParamsCommand;
import com.yuansheng.fabricdetect.java.event.hardware.HardwareStateEvent;
import com.yuansheng.fabricdetect.java.event.hardware.PulseEvent;
import com.yuansheng.fabricdetect.java.params.ParamsManager;
import com.yuansheng.fabricdetect.java.utils.DefectImageSaver;
import com.yuansheng.fabricdetect.java.utils.EventBusUtils;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 检测服务，负责图像检测处理
 */
public class DetectService {
    private static final String TAG = "DetectService";

    private final Context context;
    private final ParamsManager paramsManager;
    private DetectionService detectionService;

    // 检测线程池
    private ExecutorService executor;

    // 检测状态
    private final AtomicBoolean isRunning = new AtomicBoolean(false);
    private final AtomicBoolean isPaused = new AtomicBoolean(false);

    // 检测结果队列，用于存储待处理的结果
    private final ConcurrentLinkedQueue<DetectResult> resultQueue = new ConcurrentLinkedQueue<>();

    // 当前一圈的检测结果
    private final List<DetectionWrapper> currentCycleResults = Collections.synchronizedList(new ArrayList<>());

    private DefectImageSaver defectImageSaver;

    /**
     * 构造函数
     */
    public DetectService(Context context, DetectionService detectionService) {
        this.context = context.getApplicationContext();
        this.detectionService = detectionService;
        this.paramsManager = ParamsManager.getInstance(context);

        // 初始化线程池
        executor = Executors.newFixedThreadPool(2);

        // 注册EventBus
        EventBusUtils.register(this);

        defectImageSaver = new DefectImageSaver(context);
    }

    /**
     * 初始化检测服务
     */
    public boolean initialize() {
        Log.d(TAG, "初始化检测服务");
        try {
            // 检查检测服务是否可用
            if (detectionService == null) {
                Log.e(TAG, "检测服务实例为空");
                return false;
            }

            Log.d(TAG, "检测服务初始化成功");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "初始化检测服务失败: " + e.getMessage(), e);
            return false;
        }
    }

    /**
     * 启动检测服务
     */
    public void start() {
        if (!isRunning.get()) {
            Log.d(TAG, "启动检测服务");
            isRunning.set(true);
            isPaused.set(false);
            resultQueue.clear();
            currentCycleResults.clear();
        } else {
            Log.w(TAG, "检测服务已在运行中");
        }
    }

    /**
     * 暂停检测服务
     */
    public void pause() {
        if (isRunning.get() && !isPaused.get()) {
            Log.d(TAG, "暂停检测服务");
            isPaused.set(true);
        }
    }

    /**
     * 恢复检测服务
     */
    public void resume() {
        if (isRunning.get() && isPaused.get()) {
            Log.d(TAG, "恢复检测服务");
            isPaused.set(false);
        }
    }

    /**
     * 停止检测服务
     */
    public void stop() {
        if (isRunning.get()) {
            Log.d(TAG, "停止检测服务");
            isRunning.set(false);
            isPaused.set(false);
            resultQueue.clear();
            currentCycleResults.clear();
        } else {
            Log.w(TAG, "检测服务未在运行");
        }
    }

    /**
     * 切换检测模型
     */
    public boolean switchModel(DetectionService newDetectionService) {
        Log.d(TAG, "切换检测服务");

        // 先停止当前服务
        boolean wasRunning = isRunning.get();
        stop();

        try {
            // 替换服务
            this.detectionService = newDetectionService;

            // 如果之前在运行，重新启动服务
            if (wasRunning) {
                start();
            }

            return true;
        } catch (Exception e) {
            Log.e(TAG, "切换检测服务失败: " + e.getMessage(), e);
            return false;
        }
    }

    /**
     * 处理图像帧
     */
    public void processFrame(DirectFrame directFrame) {
        if (isRunning.get() && !isPaused.get() && directFrame != null) {
            executor.execute(() -> {
                try {
                    // 将DirectFrame转换为FrameData
                    FrameData frameData = new FrameData(directFrame);

                    // 创建包含单个帧的列表
                    List<FrameData> frameDataList = Collections.singletonList(frameData);

                    // 执行检测
                    List<FramePredictData> predictResults = detectionService.detect(frameDataList);

                    // 处理检测结果
                    if (predictResults != null && !predictResults.isEmpty()) {
                        FramePredictData predictData = predictResults.get(0);
                        DetectResult detectResult = predictData.getDetectResult();

                        if (detectResult != null) {
                            // 创建包装类实例
                            DetectionWrapper wrapper = new DetectionWrapper(detectResult, directFrame);
                            currentCycleResults.add(wrapper);

                            // 添加到结果队列中
                            resultQueue.offer(detectResult);

                            Log.d(TAG, "检测结果: " + detectResult);
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "处理图像帧失败: " + e.getMessage(), e);
                }
            });
        }
    }

    /**
     * 处理多个图像帧，用于输入一组dump图进行批量测试
     */
    public void processFrames(List<DirectFrame> directFrames) {
        if (isRunning.get() && !isPaused.get() && directFrames != null && !directFrames.isEmpty()) {
            executor.execute(() -> {
                try {
                    // 将DirectFrame列表转换为FrameData列表
                    List<FrameData> frameDataList = new ArrayList<>();
                    for (DirectFrame directFrame : directFrames) {
                        if (directFrame != null) {
                            frameDataList.add(new FrameData(directFrame));
                        }
                    }

                    if (frameDataList.isEmpty()) {
                        return;
                    }

                    // 执行批量检测
                    List<FramePredictData> predictResults = detectionService.detect(frameDataList);

                    // 处理检测结果
                    if (predictResults != null && !predictResults.isEmpty()) {
                        for (FramePredictData predictData : predictResults) {
                            DetectResult detectResult = predictData.getDetectResult();

                            if (detectResult != null) {
                                // 添加到当前圈的结果中
                                currentCycleResults.add(new DetectionWrapper(detectResult, null));

                                // 添加到结果队列中
                                resultQueue.offer(detectResult);
                            }
                        }

                        Log.d(TAG, "批量检测完成，结果数量: " + predictResults.size());

                        // 从包装类中获取检测结果列表
                        List<DetectResult> detectResults = new ArrayList<>();
                        for (DetectionWrapper wrapper : currentCycleResults) {
                            detectResults.add(wrapper.getDetectResult());
                        }
                        // 使用正确的参数类型创建事件
                        EventBusUtils.post(new CycleCompletedEvent(detectResults, 0));
                    }
                } catch (Exception e) {
                    Log.e(TAG, "批量处理图像帧失败: " + e.getMessage(), e);
                }
            });
        }
    }

    /**
     * 获取当前检测结果队列中的所有结果
     */
    public List<DetectResult> getDetectResults() {
        List<DetectResult> results = new ArrayList<>();
        DetectResult result;
        while ((result = resultQueue.poll()) != null) {
            results.add(result);
        }
        return results;
    }

    /**
     * 获取当前一圈的所有检测结果，并清空
     */
    public List<DetectResult> getCurrentCycleResults() {
        List<DetectResult> results = new ArrayList<>();
        for (DetectionWrapper wrapper : currentCycleResults) {
            results.add(wrapper.getDetectResult());
        }
        currentCycleResults.clear();
        return results;
    }

    /**
     * 接收开始检测命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onStartDetectionCommand(StartDetectionCommand command) {
        Log.d(TAG, "接收到开始检测命令");
        start();
    }

    /**
     * 接收停止检测命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onStopDetectionCommand(StopDetectionCommand command) {
        Log.d(TAG, "接收到停止检测命令: " + command.getReason());
        stop();
    }

    /**
     * 接收切换模型命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onSwitchModelCommand(SwitchModelCommand command) {
        Log.d(TAG, "接收到切换模型命令，但当前版本不支持通过直接命令切换模型");
        // 注意：现在切换模型需要通过EngineManager进行，这里不再直接处理
    }

    /**
     * 接收参数更新命令
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onUpdateParamsCommand(UpdateParamsCommand command) {
        Log.d(TAG, "接收到参数更新命令");
        // 检测相关参数更新逻辑
    }

    /**
     * 接收硬件状态事件
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onHardwareStateEvent(HardwareStateEvent event) {
        switch (event.getState()) {
            case ERROR:
                // 硬件错误，暂停检测
                Log.d(TAG, "接收到硬件错误状态，暂停检测: " + event.getMessage());
                pause();
                break;
            case STOPPED:
                // 硬件停止，停止检测
                Log.d(TAG, "接收到硬件停止状态，停止检测");
                stop();
                break;
        }
    }

    /**
     * 接收脉冲事件
     */
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onPulseEvent(PulseEvent event) {
        if (event.isCycleCompleted() && isRunning.get() && !isPaused.get()) {
            Log.d(TAG, "收到一圈完成事件");

            List<DetectResult> detectResults = new ArrayList<>();
            for (DetectionWrapper wrapper : currentCycleResults) {
                if (wrapper != null && wrapper.getDetectResult() != null) {
                    detectResults.add(wrapper.getDetectResult());
                }
            }
            // 添加帧数统计日志
            Log.d(TAG, "当前圈检测结果数量: " + detectResults.size() +
                    ", 脉冲计数: " + event.getPulseCount() +
                    ", 圈数: " + (event.getPulseCount() / paramsManager.getParams().getCycleCount()));

            // 更新图片保存器的结果
            Log.d(TAG, "更新图片保存器的当前圈结果，数量: " + currentCycleResults.size());
            defectImageSaver.setCurrentCycleResults(new ArrayList<>(currentCycleResults));

            // 先发送一圈完成事件，让DecideService进行决策
            Log.d(TAG, "发送一圈完成事件，等待决策处理");
            EventBusUtils.post(new CycleCompletedEvent(detectResults, event.getPulseCount()));

            // 注意：不要在这里清空currentCycleResults，等待决策完成后再清空
            // DecideService会在处理完后发送DecisionResultEvent
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onDecisionResultEvent(DecisionResultEvent event) {
        Log.d(TAG, "检测服务收到决策结果事件，清除当前圈结果");

        // 清除当前圈的检测结果
        currentCycleResults.clear();
    }
    /**
     * 保存最高置信度的缺陷图像
     */
    private void saveHighestConfidenceImage(DetectionWrapper wrapper, float confidence, int cycleCount) {
        try {
            // 创建可变的位图副本，用于绘制
            Bitmap mutableBitmap = wrapper.getOriginalFrame().toBitmap(true,
                    wrapper.getOriginalFrame().width(),
                    wrapper.getOriginalFrame().height(),
                    Bitmap.Config.ARGB_8888).copy(Bitmap.Config.ARGB_8888, true);

            // 创建画布和画笔
            Canvas canvas = new Canvas(mutableBitmap);
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.STROKE);  // 设置为描边模式
            paint.setColor(Color.RED);           // 设置红色
            paint.setStrokeWidth(5);             // 设置线宽

            // 设置文本画笔
            Paint textPaint = new Paint();
            textPaint.setColor(Color.RED);       // 设置红色
            textPaint.setTextSize(40);           // 设置文字大小
            textPaint.setStyle(Paint.Style.FILL);

            // 绘制所有检测到的缺陷框和得分
            DetectResult result = wrapper.getDetectResult();
            if (result != null && result.getDetects() != null) {
                for (Detect detect : result.getDetects()) {
                    // 获取缺陷框的坐标和大小
                    float centerX = detect.getX() * mutableBitmap.getWidth();  // 中心点X
                    float centerY = detect.getY() * mutableBitmap.getHeight(); // 中心点Y
                    float width = detect.getW() * mutableBitmap.getWidth();    // 宽度
                    float height = detect.getH() * mutableBitmap.getHeight();  // 高度

                    // 计算矩形的左上角和右下角坐标
                    float left = centerX - width / 2;
                    float top = centerY - height / 2;
                    float right = centerX + width / 2;
                    float bottom = centerY + height / 2;

                    // 绘制矩形框
                    canvas.drawRect(left, top, right, bottom, paint);



                    // 绘制缺陷类型和得分文本
                    String scoreText = String.format("%.2f", detect.getScore() );
                    canvas.drawText(scoreText, right + 10, centerY, textPaint);


                }
            }

            // 生成文件名，包含圈数、置信度和时间戳
            String fileName = String.format("defect_cycle%d_conf%.4f_%d.jpg",
                    cycleCount,
                    confidence,
                    System.currentTimeMillis());

            // 保存到相册
            String savedPath = MediaStore.Images.Media.insertImage(
                    context.getContentResolver(),
                    mutableBitmap,
                    fileName,
                    String.format("缺陷检测结果 - 圈数:%d, 置信度:%.4f", cycleCount, confidence)
            );

            if (savedPath != null) {
                Log.d(TAG, "已保存高置信度缺陷图像: " + fileName);

                // 发送停止检测事件并跳转到缺陷停止界面
                EventBusUtils.post(new StopDetectionCommand("检测到缺陷"));

                // 发送跳转事件，携带保存的图片路径
                Intent intent = new Intent(context, DefectStopActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("defect_image_uri", savedPath);
                context.startActivity(intent);
            } else {
                Log.e(TAG, "保存图像失败");
            }

            // 清理bitmap
            mutableBitmap.recycle();

        } catch (Exception e) {
            Log.e(TAG, "保存高置信度图像失败: " + e.getMessage(), e);
        }
    }

    /**
     * 将Image转换为Bitmap
     */
    private Bitmap imageToBitmap(Image image) {
        if (image == null) return null;

        try {
            if (image instanceof DirectFrame) {
                DirectFrame directFrame = (DirectFrame) image;
                return directFrame.toBitmap(true,
                        directFrame.width(),
                        directFrame.height(),
                        Bitmap.Config.ARGB_8888);
            }
            return null;
        } catch (Exception e) {
            Log.e(TAG, "图像转换失败: " + e.getMessage(), e);
            return null;
        }
    }

    /**
     * 释放资源
     */
    public void release() {
        Log.d(TAG, "释放检测服务资源");

        // 停止检测
        stop();

        // 关闭线程池
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
            executor = null;
        }

        // 取消EventBus注册
        EventBusUtils.unregister(this);

        // 不在这里释放detectionService，因为它由EngineManager管理
        this.detectionService = null;
    }
}

/**
 * 包装检测结果和原始帧
 */
